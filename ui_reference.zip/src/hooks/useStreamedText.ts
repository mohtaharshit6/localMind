import { useEffect, useRef, useState } from 'react';

/**
 * Reveals text progressively to mimic a locally-streaming model.
 * Returns the visible slice plus whether it is still streaming.
 */
export function useStreamedText(text: string, enabled: boolean, charsPerTick = 6) {
  const [count, setCount] = useState(enabled ? 0 : text.length);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (!enabled) {
      setCount(text.length);
      return;
    }
    setCount(0);
    const reduce =
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) {
      setCount(text.length);
      return;
    }
    timer.current = window.setInterval(() => {
      setCount((c) => {
        if (c >= text.length) {
          if (timer.current) window.clearInterval(timer.current);
          return c;
        }
        return c + charsPerTick;
      });
    }, 16);
    return () => {
      if (timer.current) window.clearInterval(timer.current);
    };
  }, [text, enabled, charsPerTick]);

  return { visible: text.slice(0, count), streaming: count < text.length };
}