import type { ChatMessage, Source } from '../types';

const paperSources: Source[] = [
{
  id: 'src1',
  fileName: 'attention-retrieval-2026.pdf',
  kind: 'pdf',
  location: 'p. 7 · §4.2 Results',
  relevance: 0.94,
  evidence:
  'Across all three benchmarks, hybrid retrieval reduced hallucinated citations by 41% relative to dense-only retrieval, while adding just 12ms of median latency per query.'
},
{
  id: 'src2',
  fileName: 'attention-retrieval-2026.pdf',
  kind: 'pdf',
  location: 'p. 11 · §5 Discussion',
  relevance: 0.88,
  evidence:
  'The gains concentrate in long-tail queries: for documents longer than 40 pages, chunk-level reranking accounted for 68% of the total improvement.'
},
{
  id: 'src3',
  fileName: 'interview-notes.txt',
  kind: 'txt',
  location: 'lines 42–58',
  relevance: 0.71,
  evidence:
  'Two of the four reviewers independently raised the same concern: the ablation study omits the no-reranker condition, which makes the headline number hard to attribute.'
}];


export const seededConversation: ChatMessage[] = [
{
  id: 'm1',
  role: 'user',
  text: 'Find the main findings in my research paper'
},
{
  id: 'm2',
  role: 'assistant',
  latencyMs: 820,
  tokens: 214,
  text: `Three findings carry the paper.

Hybrid retrieval is the headline result. Combining sparse and dense retrieval cut hallucinated citations by 41% against a dense-only baseline, and it cost only 12ms of median latency — the trade the paper argues is worth making.

The benefit is concentrated, not uniform. On documents over 40 pages, chunk-level reranking alone accounts for 68% of the improvement. Short documents see almost none of it, which reframes the contribution as a long-document technique rather than a general one.

The evaluation has one gap worth addressing. The ablation omits a no-reranker condition, so the 41% figure cannot be cleanly attributed between retrieval and reranking. Your own interview notes flag this twice, from two independent reviewers.`,
  sources: paperSources
}];


export const cannedReplies: Record<string, ChatMessage> = {
  default: {
    id: 'canned-default',
    role: 'assistant',
    latencyMs: 640,
    tokens: 168,
    text: `I searched your four authorized folders and found 3 passages above the relevance threshold.

The strongest match sits in your project scope document: the Q3 milestone was moved from September 14 to October 2, and the dependency on the ingestion rewrite is the stated reason. The revision history confirms that change landed in v4 and was not present in v3.

Two supporting mentions appear in your interview notes, both describing the same slip from the engineering side.`,
    sources: paperSources.slice(0, 2)
  },
  files: {
    id: 'canned-files',
    role: 'assistant',
    latencyMs: 310,
    tokens: 96,
    text: `No C++ sources are indexed in this workspace.

Your authorized folders contain only PDF, DOCX, TXT and CSV files — 128 in total. If your code lives elsewhere, you can authorize that folder from the sidebar and I'll index it without moving anything.

I can also list every file extension I currently see, so you can confirm nothing was skipped.`,
    sources: []
  }
};