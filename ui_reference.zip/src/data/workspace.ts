import type { Folder, PromptSuggestion, WorkspaceFile } from '../types';

export const workspaceName = 'Research — Q3';

export const folders: Folder[] = [
{
  id: 'f1',
  name: 'Research Papers',
  path: '~/Documents/Research',
  fileCount: 42,
  status: 'indexed',
  permission: 'read'
},
{
  id: 'f2',
  name: 'Project Atlas',
  path: '~/Work/atlas',
  fileCount: 61,
  status: 'indexed',
  permission: 'read & write'
},
{
  id: 'f3',
  name: 'Sales Exports',
  path: '~/Downloads/exports',
  fileCount: 18,
  status: 'indexing',
  permission: 'read',
  progress: 0.64
},
{
  id: 'f4',
  name: 'Archive 2024',
  path: '~/Documents/Archive',
  fileCount: 7,
  status: 'paused',
  permission: 'read'
}];


export const systemStatus = {
  filesIndexed: 128,
  sources: 4,
  chunks: 9412,
  llm: {
    name: 'Llama 3.1 8B',
    runtime: 'local · Metal',
    state: 'ready' as 'ready' | 'loading' | 'offline',
    latency: '38 tok/s'
  },
  embedder: 'bge-small-en · local',
  indexHealth: 0.94,
  lastSweep: '2 min ago'
};

export const recentlyIndexed: WorkspaceFile[] = [
{
  id: 'r1',
  name: 'attention-retrieval-2026.pdf',
  kind: 'pdf',
  folder: 'Research Papers',
  sizeLabel: '2.4 MB',
  indexedAt: '2 min ago',
  chunks: 184
},
{
  id: 'r2',
  name: 'atlas-scope-v4.docx',
  kind: 'docx',
  folder: 'Project Atlas',
  sizeLabel: '312 KB',
  indexedAt: '14 min ago',
  chunks: 46
},
{
  id: 'r3',
  name: 'regional_sales_q3.csv',
  kind: 'csv',
  folder: 'Sales Exports',
  sizeLabel: '1.1 MB',
  indexedAt: '26 min ago',
  chunks: 12
},
{
  id: 'r4',
  name: 'interview-notes.txt',
  kind: 'txt',
  folder: 'Research Papers',
  sizeLabel: '18 KB',
  indexedAt: '1 hr ago',
  chunks: 9
},
{
  id: 'r5',
  name: 'atlas-scope-v3.docx',
  kind: 'docx',
  folder: 'Project Atlas',
  sizeLabel: '288 KB',
  indexedAt: '3 hr ago',
  chunks: 41
}];


export const promptSuggestions: PromptSuggestion[] = [
{
  id: 's1',
  label: 'Find the main findings in my research paper',
  scope: 'attention-retrieval-2026.pdf',
  intent: 'ask'
},
{
  id: 's2',
  label: 'Compare my project documents',
  scope: 'atlas-scope v3 ↔ v4',
  intent: 'compare'
},
{
  id: 's3',
  label: 'What are the highest performing regions?',
  scope: 'regional_sales_q3.csv',
  intent: 'csv'
},
{
  id: 's4',
  label: 'Find all C++ files',
  scope: '4 authorized folders',
  intent: 'files'
}];