import type { FileKind } from '../types';

export interface DocMeta {
  name: string;
  kind: FileKind;
  folder: string;
  pages: string;
  words: string;
  modified: string;
  indexed: string;
}

export const summarizeDoc = {
  meta: {
    name: 'attention-retrieval-2026.pdf',
    kind: 'pdf' as FileKind,
    folder: '~/Documents/Research',
    pages: '24 pages',
    words: '9,140 words',
    modified: 'Sep 4, 2026',
    indexed: '2 min ago · 184 chunks'
  },
  abstractLabel: 'Summary · local model, no data left this device',
  summary: `The paper proposes a hybrid retrieval pipeline that pairs sparse lexical matching with dense embeddings, then applies chunk-level reranking before generation. Evaluated on three long-document benchmarks, it reduces hallucinated citations by 41% against a dense-only baseline at a cost of 12ms median latency.

The improvement is not evenly distributed. Gains cluster on documents longer than forty pages, where reranking contributes roughly two thirds of the total effect. The authors position this as evidence that retrieval quality, not model scale, is the binding constraint for document question answering.`,
  keyPoints: [
  {
    id: 'k1',
    text: 'Hybrid sparse + dense retrieval cuts hallucinated citations 41% vs. dense-only.',
    cite: 'p. 7 · §4.2'
  },
  {
    id: 'k2',
    text: 'Added latency is 12ms median — negligible relative to generation time.',
    cite: 'p. 8 · Table 3'
  },
  {
    id: 'k3',
    text: 'On 40+ page documents, chunk reranking drives 68% of the improvement.',
    cite: 'p. 11 · §5'
  },
  {
    id: 'k4',
    text: 'Retrieval quality, not parameter count, is framed as the binding constraint.',
    cite: 'p. 12 · §5.3'
  },
  {
    id: 'k5',
    text: 'The ablation omits a no-reranker condition, weakening attribution.',
    cite: 'p. 15 · Appendix B'
  }],

  plan: [
  {
    id: 'p1',
    title: 'Add the missing ablation',
    detail:
    'Run the no-reranker condition on all three benchmarks so the 41% figure can be split between retrieval and reranking.',
    effort: 'High impact'
  },
  {
    id: 'p2',
    title: 'Reframe the contribution',
    detail:
    'The abstract claims a general result; the evidence supports a long-document result. Narrow the claim in §1 and §5.',
    effort: 'Editorial'
  },
  {
    id: 'p3',
    title: 'Surface the latency table earlier',
    detail:
    'Table 3 answers the first objection reviewers raise. Move it from p. 8 into §4.1 alongside the headline result.',
    effort: 'Low effort'
  }]

};

export const compareDocs = {
  left: {
    meta: {
      name: 'atlas-scope-v3.docx',
      kind: 'docx' as FileKind,
      folder: '~/Work/atlas',
      pages: '11 pages',
      words: '3,280 words',
      modified: 'Aug 19, 2026',
      indexed: '3 hr ago · 41 chunks'
    },
    label: 'Baseline'
  },
  right: {
    meta: {
      name: 'atlas-scope-v4.docx',
      kind: 'docx' as FileKind,
      folder: '~/Work/atlas',
      pages: '14 pages',
      words: '4,015 words',
      modified: 'Sep 5, 2026',
      indexed: '14 min ago · 46 chunks'
    },
    label: 'Current'
  },
  similarities: [
  'Both documents keep the same three workstreams: ingestion, retrieval and the review surface.',
  'Success criteria are unchanged — 95% index coverage and sub-second median query time.',
  'The named owners for each workstream are identical across both versions.',
  'Out-of-scope list is preserved verbatim, including mobile and multi-tenant support.'],

  differences: [
  {
    id: 'd1',
    topic: 'Q3 milestone date',
    left: 'September 14, 2026',
    right: 'October 2, 2026',
    severity: 'risk' as const,
    note: 'An 18-day slip, attributed to the ingestion rewrite.'
  },
  {
    id: 'd2',
    topic: 'Ingestion approach',
    left: 'Incremental parser patches',
    right: 'Full rewrite on a streaming parser',
    severity: 'risk' as const,
    note: 'Materially larger scope than the baseline described.'
  },
  {
    id: 'd3',
    topic: 'Headcount',
    left: '4 engineers',
    right: '5 engineers + 1 designer',
    severity: 'info' as const,
    note: 'Added capacity partially offsets the schedule change.'
  },
  {
    id: 'd4',
    topic: 'Evaluation harness',
    left: 'Not mentioned',
    right: 'New §6, owned by the retrieval workstream',
    severity: 'info' as const,
    note: 'Net-new section, 720 words.'
  }],

  evidence: [
  {
    id: 'e1',
    file: 'atlas-scope-v4.docx',
    location: 'p. 4 · §2.1 Timeline',
    quote:
    'The Q3 milestone moves to October 2 to absorb the ingestion rewrite. Downstream review-surface work is unaffected because it depends only on the stable chunk contract.'
  },
  {
    id: 'e2',
    file: 'atlas-scope-v3.docx',
    location: 'p. 3 · §2.1 Timeline',
    quote:
    'Q3 milestone: September 14. Ingestion improvements land as incremental parser patches against the existing pipeline.'
  }]

};