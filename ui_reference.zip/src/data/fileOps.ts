import type { FileOperation } from '../types';

export const operations: FileOperation[] = [
{
  id: 'op_8f21c',
  title: 'Normalize scope document filenames',
  summary:
  'Rename three Project Atlas documents to the dated convention used elsewhere in the folder. Index references are rewritten automatically.',
  kind: 'rename',
  destructive: false,
  scope: '~/Work/atlas · read & write',
  requestedBy: '“Rename my scope docs to match the dated convention”',
  changes: [
  {
    id: 'c1',
    from: 'atlas-scope-v4.docx',
    to: 'atlas-scope-2026-09-final.docx',
    note: '46 index chunks re-pointed'
  },
  {
    id: 'c2',
    from: 'atlas-scope-v3.docx',
    to: 'atlas-scope-2026-08.docx',
    note: '41 index chunks re-pointed'
  },
  {
    id: 'c3',
    from: 'scope notes (copy).txt',
    to: 'atlas-scope-notes-2026-08.txt',
    note: '9 index chunks re-pointed'
  }]

},
{
  id: 'op_4a90d',
  title: 'Archive superseded exports',
  summary:
  'Move 12 CSV exports older than 90 days out of Sales Exports and into Archive 2024. Files are moved, never rewritten.',
  kind: 'move',
  destructive: false,
  scope: '~/Downloads/exports → ~/Documents/Archive',
  requestedBy: '“Archive anything older than a quarter”',
  changes: [
  { id: 'c4', from: 'regional_sales_q1.csv', to: 'Archive 2024/', note: '1.0 MB' },
  { id: 'c5', from: 'regional_sales_q2.csv', to: 'Archive 2024/', note: '1.1 MB' },
  { id: 'c6', from: 'pipeline_snapshot_apr.csv', to: 'Archive 2024/', note: '840 KB' },
  { id: 'c7', from: '+9 more matching files', to: 'Archive 2024/', note: '7.4 MB total' }]

},
{
  id: 'op_2c17f',
  title: 'Delete duplicate downloads',
  summary:
  'Permanently remove 6 byte-identical duplicates. This cannot be undone from within LocalMind — originals are kept, copies are destroyed.',
  kind: 'delete',
  destructive: true,
  scope: '~/Downloads/exports · read & write',
  requestedBy: '“Clean up the duplicate exports”',
  changes: [
  { id: 'c8', from: 'regional_sales_q3 (1).csv', to: 'deleted', note: 'identical to original' },
  { id: 'c9', from: 'regional_sales_q3 (2).csv', to: 'deleted', note: 'identical to original' },
  { id: 'c10', from: 'atlas-scope-v4 (1).docx', to: 'deleted', note: 'identical to original' },
  { id: 'c11', from: '+3 more duplicates', to: 'deleted', note: '2.8 MB reclaimed' }]

}];


export const stageOrder = ['proposed', 'review', 'confirm', 'executing', 'verified'] as const;

export const stageCopy: Record<
  (typeof stageOrder)[number],
  {label: string;caption: string;}> =
{
  proposed: { label: 'Proposed', caption: 'LocalMind drafted this action from your request' },
  review: { label: 'Review', caption: 'Inspect every change before anything is written' },
  confirm: { label: 'Confirm', caption: 'Your explicit approval is required to proceed' },
  executing: { label: 'Executing', caption: 'Applying changes and updating the index' },
  verified: { label: 'Verified', caption: 'Checksums matched and references re-pointed' }
};