export const dataset = {
  name: 'regional_sales_q3.csv',
  folder: '~/Downloads/exports',
  rows: 18420,
  columns: 9,
  sizeLabel: '1.1 MB',
  indexed: '26 min ago',
  quality: 0.97,
  nullCells: 213,
  schema: [
  { name: 'region', type: 'string', unique: 6 },
  { name: 'rep', type: 'string', unique: 84 },
  { name: 'segment', type: 'string', unique: 3 },
  { name: 'revenue', type: 'number', unique: 12904 },
  { name: 'units', type: 'number', unique: 842 },
  { name: 'margin', type: 'number', unique: 1180 },
  { name: 'closed_at', type: 'date', unique: 92 }]

};

export const headlineMetric = {
  label: 'Total revenue · Q3',
  value: '$8.42M',
  delta: '+14.2%',
  deltaLabel: 'vs. Q2',
  positive: true
};

export const secondaryMetrics = [
{ label: 'Avg. deal size', value: '$4,570', delta: '+3.1%', positive: true },
{ label: 'Gross margin', value: '38.4%', delta: '−1.6%', positive: false },
{ label: 'Units sold', value: '1,842', delta: '+9.8%', positive: true },
{ label: 'Active reps', value: '84', delta: '+4', positive: true }];


export const regionRevenue = [
{ region: 'North', revenue: 2410, margin: 41.2 },
{ region: 'West', revenue: 1980, margin: 39.8 },
{ region: 'South', revenue: 1420, margin: 36.4 },
{ region: 'Central', revenue: 1180, margin: 35.1 },
{ region: 'East', revenue: 920, margin: 33.7 },
{ region: 'Islands', revenue: 510, margin: 30.2 }];


export const monthlyTrend = [
{ month: 'Apr', revenue: 2180, forecast: 2200 },
{ month: 'May', revenue: 2320, forecast: 2280 },
{ month: 'Jun', revenue: 2410, forecast: 2400 },
{ month: 'Jul', revenue: 2680, forecast: 2520 },
{ month: 'Aug', revenue: 2840, forecast: 2700 },
{ month: 'Sep', revenue: 2900, forecast: 2860 }];


export const insights = [
{
  id: 'i1',
  title: 'North and West carry 52% of Q3 revenue',
  detail:
  'North ($2.41M) and West ($1.98M) together account for 52.1% of the quarter. North also holds the highest margin at 41.2%, so growth there is not being bought with discounting.',
  columns: ['region', 'revenue', 'margin']
},
{
  id: 'i2',
  title: 'Islands is the only region shrinking',
  detail:
  'Islands fell 8.4% quarter over quarter on 30.2% margin — the lowest on both measures. Two of its four reps closed nothing in September.',
  columns: ['region', 'revenue', 'rep']
},
{
  id: 'i3',
  title: 'Margin erosion is concentrated in one segment',
  detail:
  'The 1.6 point margin decline comes almost entirely from Enterprise deals over $20k, where discount depth rose from 11% to 17%.',
  columns: ['segment', 'margin', 'revenue']
}];


export const csvQuestions = [
'What are the highest performing regions?',
'Which reps are below quota in Islands?',
'Show margin by segment over time'];