import type { ActivityEvent } from '../types';

export const activity: ActivityEvent[] = [
{
  id: 'a1',
  kind: 'indexed',
  title: 'Indexed 184 chunks',
  detail: 'attention-retrieval-2026.pdf added to the Research Papers index',
  time: '14:32',
  day: 'Today',
  target: '~/Documents/Research'
},
{
  id: 'a2',
  kind: 'searched',
  title: 'Semantic search — “main findings”',
  detail: '6 candidate passages, 3 above relevance threshold',
  time: '14:33',
  day: 'Today',
  target: '2 files'
},
{
  id: 'a3',
  kind: 'summarized',
  title: 'Summarized attention-retrieval-2026.pdf',
  detail: '24 pages condensed into 5 key points and a revision plan',
  time: '14:41',
  day: 'Today',
  target: 'local · Llama 3.1 8B'
},
{
  id: 'a4',
  kind: 'renamed',
  title: 'Renamed 3 files',
  detail: 'atlas-scope-v4.docx → atlas-scope-2026-09-final.docx (+2 more)',
  time: '15:02',
  day: 'Today',
  target: '~/Work/atlas'
},
{
  id: 'a5',
  kind: 'verified',
  title: 'Verified write operation',
  detail: 'Checksums matched on 3 of 3 files, index references updated',
  time: '15:02',
  day: 'Today',
  target: 'op_8f21c'
},
{
  id: 'a6',
  kind: 'compared',
  title: 'Compared atlas-scope v3 ↔ v4',
  detail: '11 similarities, 6 material differences, 2 flagged as scope risk',
  time: '11:18',
  day: 'Yesterday',
  target: '~/Work/atlas'
},
{
  id: 'a7',
  kind: 'moved',
  title: 'Moved 12 files to Archive 2024',
  detail: 'Confirmed by user before execution, rollback token retained 7 days',
  time: '10:44',
  day: 'Yesterday',
  target: '~/Documents/Archive'
},
{
  id: 'a8',
  kind: 'created',
  title: 'Created regional-summary.md',
  detail: 'Generated from regional_sales_q3.csv analysis',
  time: '09:57',
  day: 'Yesterday',
  target: '~/Downloads/exports'
}];