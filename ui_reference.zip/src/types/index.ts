export type FileKind = 'pdf' | 'docx' | 'txt' | 'csv' | 'code';

export type ViewId = 'ask' | 'summarize' | 'compare' | 'csv' | 'files' | 'activity';

export type IndexStatus = 'indexed' | 'indexing' | 'paused' | 'error';

export interface Folder {
  id: string;
  name: string;
  path: string;
  fileCount: number;
  status: IndexStatus;
  permission: 'read' | 'read & write';
  progress?: number;
}

export interface WorkspaceFile {
  id: string;
  name: string;
  kind: FileKind;
  folder: string;
  sizeLabel: string;
  indexedAt: string;
  chunks: number;
}

export interface Source {
  id: string;
  fileName: string;
  kind: FileKind;
  location: string;
  relevance: number;
  evidence: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  sources?: Source[];
  latencyMs?: number;
  tokens?: number;
}

export interface PromptSuggestion {
  id: string;
  label: string;
  scope: string;
  intent: 'ask' | 'compare' | 'csv' | 'files';
}

export type ActivityKind =
'indexed' |
'searched' |
'summarized' |
'compared' |
'created' |
'moved' |
'renamed' |
'verified';

export interface ActivityEvent {
  id: string;
  kind: ActivityKind;
  title: string;
  detail: string;
  time: string;
  day: string;
  target?: string;
}

export type OpStage = 'proposed' | 'review' | 'confirm' | 'executing' | 'verified';

export interface OpChange {
  id: string;
  from: string;
  to: string;
  note: string;
}

export interface FileOperation {
  id: string;
  title: string;
  summary: string;
  kind: 'rename' | 'move' | 'create' | 'delete';
  destructive: boolean;
  scope: string;
  changes: OpChange[];
  requestedBy: string;
}