import React, { useMemo, useState } from 'react';
import type { ChatMessage, Source, ViewId } from './types';
import { Sidebar } from './components/layout/Sidebar';
import { TopBar } from './components/layout/TopBar';
import { ContextPanel } from './components/layout/ContextPanel';
import { AskView } from './components/ask/AskView';
import { SummarizeView } from './components/summarize/SummarizeView';
import { CompareView } from './components/compare/CompareView';
import { CsvView } from './components/csv/CsvView';
import { FileOperationsView } from './components/files/FileOperationsView';
import { ActivityView } from './components/activity/ActivityView';
import { cannedReplies, seededConversation } from './data/conversation';

interface AppProps {
  /** Which workspace opens first. */
  initialView?: 'ask' | 'summarize' | 'compare' | 'csv' | 'files' | 'activity';
  /** Open Ask with an answered question instead of the hero state. */
  startWithConversation?: boolean;
  /** Show the Workspace Context rail on wide screens. */
  showContextPanel?: boolean;
}

function replyFor(text: string): ChatMessage {
  const q = text.toLowerCase();
  const id = `a-${Date.now()}`;
  if (q.includes('c++') || q.includes('.cpp') || q.includes('code file')) {
    return { ...cannedReplies.files, id };
  }
  if (q.includes('finding') || q.includes('research') || q.includes('paper')) {
    return { ...seededConversation[1], id };
  }
  return { ...cannedReplies.default, id };
}

export function App({
  initialView = 'ask',
  startWithConversation = false,
  showContextPanel = true
}: AppProps) {
  const [view, setView] = useState<ViewId>(initialView);
  const [contextOpen, setContextOpen] = useState(showContextPanel);
  const [messages, setMessages] = useState<ChatMessage[]>(
    startWithConversation ? seededConversation : []
  );
  const [streamingId, setStreamingId] = useState<string | null>(null);

  const handleSubmit = (text: string) => {
    const userMsg: ChatMessage = { id: `u-${Date.now()}`, role: 'user', text };
    const reply = replyFor(text);
    setMessages((prev) => [...prev, userMsg, reply]);
    setStreamingId(reply.id);
    window.setTimeout(
      () => setStreamingId((cur) => cur === reply.id ? null : cur),
      Math.min(6000, reply.text.length * 3 + 400)
    );
  };

  const relevantSources = useMemo<Source[]>(() => {
    if (view === 'ask') {
      const last = [...messages].reverse().find((m) => m.role === 'assistant' && m.sources?.length);
      return last?.sources ?? [];
    }
    return [];
  }, [messages, view]);

  return (
    <div className="app-wash flex h-full min-h-full w-full overflow-hidden font-sans text-ink">
      <Sidebar view={view} onChangeView={setView} />

      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar
          view={view}
          contextOpen={contextOpen}
          onToggleContext={() => setContextOpen((o) => !o)} />
        
        <div className="flex min-h-0 flex-1">
          <main className="flex min-w-0 flex-1 flex-col">
            {view === 'ask' &&
            <AskView messages={messages} streamingId={streamingId} onSubmit={handleSubmit} />
            }
            {view === 'summarize' && <SummarizeView />}
            {view === 'compare' && <CompareView />}
            {view === 'csv' && <CsvView />}
            {view === 'files' && <FileOperationsView />}
            {view === 'activity' && <ActivityView />}
          </main>
          {contextOpen && <ContextPanel sources={relevantSources} />}
        </div>
      </div>
    </div>);

}