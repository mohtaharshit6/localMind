import React from 'react';
import { motion } from 'framer-motion';
import {
  ArrowUpRightIcon,
  CheckCircle2Icon,
  DownloadIcon,
  RefreshCwIcon,
  SlidersHorizontalIcon } from
'lucide-react';
import { summarizeDoc } from '../../data/documents';
import { FileIcon } from '../ui/FileIcon';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { KeyValue, SectionLabel } from '../ui/Panel';

export function SummarizeView() {
  const { meta, summary, keyPoints, plan } = summarizeDoc;

  return (
    <div className="min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto max-w-[900px] px-8 py-8">
        {/* Document header — the object of the workspace, so it wins the page */}
        <motion.header
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.24, ease: [0.23, 1, 0.32, 1] }}>
          
          <div className="flex items-start gap-3.5">
            <FileIcon kind={meta.kind} />
            <div className="min-w-0 flex-1">
              <h1 className="truncate font-display text-2xl font-semibold text-ink">
                {meta.name}
              </h1>
              <p className="mt-1 font-mono text-[11px] text-ink-ghost">{meta.folder}</p>
            </div>
            <div className="flex shrink-0 items-center gap-1.5">
              <Button size="sm" variant="ghost" icon={<SlidersHorizontalIcon className="h-3.5 w-3.5" strokeWidth={1.9} />}>
                Length
              </Button>
              <Button size="sm" variant="ghost" icon={<RefreshCwIcon className="h-3.5 w-3.5" strokeWidth={1.9} />}>
                Re-run
              </Button>
              <Button size="sm" variant="secondary" icon={<DownloadIcon className="h-3.5 w-3.5" strokeWidth={1.9} />}>
                Export
              </Button>
            </div>
          </div>

          <dl className="mt-5 grid grid-cols-2 gap-x-8 gap-y-4 border-t border-white/[0.055] pt-4 sm:grid-cols-4">
            <KeyValue label="Extent" value={meta.pages} />
            <KeyValue label="Length" value={meta.words} />
            <KeyValue label="Modified" value={meta.modified} />
            <KeyValue label="Indexed" value={meta.indexed} mono />
          </dl>
        </motion.header>

        {/* Summary — the primary answer */}
        <section className="mt-9">
          <SectionLabel
            className="mb-3"
            action={
            <Badge tone="jade">
                <CheckCircle2Icon className="h-3 w-3" strokeWidth={2.2} />
                grounded in 24 pages
              </Badge>
            }>
            
            Summary
          </SectionLabel>
          <div className="space-y-4">
            {summary.split('\n\n').map((p, i) =>
            <p
              key={i}
              className={
              i === 0 ?
              'text-lg leading-[28px] text-ink' :
              'text-md leading-[25px] text-ink-dim'
              }>
              
                {p}
              </p>
            )}
          </div>
          <p className="mt-3 font-mono text-[10.5px] text-ink-ghost">
            {summarizeDoc.abstractLabel}
          </p>
        </section>

        {/* Key points */}
        <section className="mt-10">
          <SectionLabel className="mb-2.5">Key points</SectionLabel>
          <ul className="divide-y divide-white/[0.045]">
            {keyPoints.map((k, i) =>
            <li key={k.id} className="group flex items-start gap-3.5 py-3">
                <span className="mt-[3px] w-4 shrink-0 font-mono text-[10.5px] text-ink-ghost">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <p className="flex-1 text-md leading-[24px] text-ink-dim transition-colors duration-150 group-hover:text-ink">
                  {k.text}
                </p>
                <button
                type="button"
                className="mt-px flex shrink-0 items-center gap-1 rounded-md px-1.5 py-0.5 font-mono text-[10.5px] text-ink-ghost transition-colors duration-150 ease-swift hover:bg-white/[0.05] hover:text-jade-300">
                
                  {k.cite}
                  <ArrowUpRightIcon className="h-2.5 w-2.5" strokeWidth={2.4} />
                </button>
              </li>
            )}
          </ul>
        </section>

        {/* Revision plan — sequential, so it reads as a plan not a card grid */}
        <section className="mt-10 pb-4">
          <SectionLabel className="mb-3.5">Revision plan</SectionLabel>
          <ol className="relative space-y-5 pl-5">
            <span className="absolute left-[5px] top-1.5 h-[calc(100%-1.5rem)] w-px bg-white/[0.07]" />
            {plan.map((step) =>
            <li key={step.id} className="relative">
                <span className="absolute -left-5 top-1.5 h-[9px] w-[9px] rounded-full bg-surface-high shadow-[inset_0_0_0_1px_rgba(255,255,255,0.14)]" />
                <div className="flex items-center gap-2">
                  <h4 className="text-md font-medium tracking-[-0.01em] text-ink">{step.title}</h4>
                  <Badge tone={step.effort === 'High impact' ? 'jade' : 'neutral'}>
                    {step.effort}
                  </Badge>
                </div>
                <p className="mt-1 max-w-[620px] text-base leading-[21px] text-ink-faint">
                  {step.detail}
                </p>
              </li>
            )}
          </ol>
        </section>
      </div>
    </div>);

}