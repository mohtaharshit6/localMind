import React from 'react';
import { CheckIcon, Loader2Icon } from 'lucide-react';
import type { OpStage } from '../../types';
import { stageCopy, stageOrder } from '../../data/fileOps';
import { cn } from '../../utils/cn';

export function StageTrack({
  stage,
  destructive



}: {stage: OpStage;destructive: boolean;}) {
  const currentIndex = stageOrder.indexOf(stage);

  return (
    <ol className="flex items-stretch">
      {stageOrder.map((s, i) => {
        const done = i < currentIndex;
        const active = i === currentIndex;
        const dangerNow = active && destructive && s === 'confirm';
        return (
          <li key={s} className="flex min-w-0 flex-1 items-start gap-2.5">
            <div className="flex flex-col items-center">
              <span
                className={cn(
                  'flex h-5 w-5 shrink-0 items-center justify-center rounded-full transition-colors duration-200 ease-swift',
                  done && 'bg-jade-900 text-jade-300',
                  active && !dangerNow && 'bg-jade-500 text-void',
                  dangerNow && 'bg-danger-500 text-void',
                  !done && !active && 'bg-white/[0.05] text-ink-ghost'
                )}>
                
                {done ?
                <CheckIcon className="h-3 w-3" strokeWidth={3} /> :
                active && s === 'executing' ?
                <Loader2Icon className="h-3 w-3 animate-spin" strokeWidth={2.6} /> :

                <span className="font-mono text-[9.5px] font-semibold">{i + 1}</span>
                }
              </span>
            </div>
            <div className="min-w-0 flex-1 pr-3">
              <p
                className={cn(
                  'truncate text-sm font-medium transition-colors duration-200',
                  active ? dangerNow ? 'text-danger-400' : 'text-ink' : done ? 'text-ink-dim' : 'text-ink-ghost'
                )}>
                
                {stageCopy[s].label}
              </p>
              {active &&
              <p className="mt-0.5 text-xs leading-4 text-ink-faint">{stageCopy[s].caption}</p>
              }
              {i < stageOrder.length - 1 &&
              <span
                className={cn(
                  'mt-2 block h-px w-full transition-colors duration-300',
                  done ? 'bg-jade-700' : 'bg-white/[0.07]'
                )} />

              }
            </div>
          </li>);

      })}
    </ol>);

}