import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowRightIcon,
  CheckCircle2Icon,
  FilePlus2Icon,
  FolderInputIcon,
  PencilLineIcon,
  RotateCcwIcon,
  ShieldAlertIcon,
  Trash2Icon,
  UndoIcon } from
'lucide-react';
import type { FileOperation, OpStage } from '../../types';
import { operations } from '../../data/fileOps';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Meter, SectionLabel } from '../ui/Panel';
import { StageTrack } from './StageTrack';
import { cn } from '../../utils/cn';

const kindIcon = {
  rename: PencilLineIcon,
  move: FolderInputIcon,
  create: FilePlus2Icon,
  delete: Trash2Icon
};

function OpListItem({
  op,
  selected,
  onSelect




}: {op: FileOperation;selected: boolean;onSelect: () => void;}) {
  const Icon = kindIcon[op.kind];
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-current={selected}
      className={cn(
        'group flex w-full items-start gap-2.5 rounded-lg px-2.5 py-2.5 text-left',
        'transition-colors duration-150 ease-swift',
        selected ? 'bg-white/[0.055]' : 'hover:bg-white/[0.03]'
      )}>
      
      <span
        className={cn(
          'mt-px inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-md',
          op.destructive ? 'bg-danger-900 text-danger-400' : 'bg-white/[0.05] text-ink-dim'
        )}>
        
        <Icon className="h-3.5 w-3.5" strokeWidth={1.9} />
      </span>
      <span className="min-w-0 flex-1">
        <span
          className={cn(
            'block truncate text-base font-medium transition-colors',
            selected ? 'text-ink' : 'text-ink-dim group-hover:text-ink'
          )}>
          
          {op.title}
        </span>
        <span className="mt-0.5 block font-mono text-[10px] text-ink-ghost">
          {op.id} · {op.changes.length} changes
        </span>
      </span>
      {op.destructive &&
      <ShieldAlertIcon className="mt-1 h-3.5 w-3.5 shrink-0 text-danger-500" strokeWidth={2} />
      }
    </button>);

}

export function FileOperationsView() {
  const [selectedId, setSelectedId] = useState(operations[0].id);
  const [stage, setStage] = useState<OpStage>('proposed');
  const [ack, setAck] = useState(false);
  const op = operations.find((o) => o.id === selectedId) ?? operations[0];

  useEffect(() => {
    setStage('proposed');
    setAck(false);
  }, [selectedId]);

  useEffect(() => {
    if (stage !== 'executing') return;
    const t = window.setTimeout(() => setStage('verified'), 1600);
    return () => window.clearTimeout(t);
  }, [stage]);

  const nextStage: OpStage =
  stage === 'proposed' ? 'review' : stage === 'review' && !op.destructive ? 'confirm' : 'executing';
  const blocked = op.destructive && stage !== 'proposed' && !ack;

  return (
    <div className="min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto grid max-w-[1040px] grid-cols-1 gap-8 px-8 py-8 lg:grid-cols-[264px_1fr]">
        {/* Queue */}
        <aside>
          <SectionLabel className="mb-2.5" action={<Badge mono>{operations.length}</Badge>}>
            Pending actions
          </SectionLabel>
          <div className="-mx-2.5 space-y-0.5">
            {operations.map((o) =>
            <OpListItem
              key={o.id}
              op={o}
              selected={o.id === selectedId}
              onSelect={() => setSelectedId(o.id)} />

            )}
          </div>
          <p className="mt-4 text-xs leading-4 text-ink-ghost">
            LocalMind never writes to disk without an explicit confirmation, and keeps a rollback
            token for seven days.
          </p>
        </aside>

        {/* Detail */}
        <div className="min-w-0">
          <motion.header
            key={op.id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.24, ease: [0.23, 1, 0.32, 1] }}>
            
            <div className="flex items-center gap-2">
              <h1 className="font-display text-2xl font-semibold text-ink">{op.title}</h1>
              {op.destructive &&
              <Badge tone="danger">
                  <ShieldAlertIcon className="h-3 w-3" strokeWidth={2.2} />
                  Destructive
                </Badge>
              }
            </div>
            <p className="mt-2 max-w-[620px] text-md leading-[24px] text-ink-faint">{op.summary}</p>
            <p className="mt-3 font-mono text-[10.5px] text-ink-ghost">
              scope {op.scope} · from {op.requestedBy}
            </p>
          </motion.header>

          <div className="mt-7 rounded-xl bg-surface-raised px-4 py-4 shadow-ring">
            <StageTrack stage={stage} destructive={op.destructive} />
          </div>

          {/* Review changes */}
          <section className="mt-6">
            <SectionLabel
              className="mb-2.5"
              action={
              <span className="font-mono text-[10px] text-ink-ghost">
                  {op.changes.length} affected paths
                </span>
              }>
              
              Review changes
            </SectionLabel>
            <ul
              className={cn(
                'overflow-hidden rounded-xl shadow-ring',
                op.destructive ? 'bg-danger-900/25' : 'bg-surface-raised/70'
              )}>
              
              {op.changes.map((c, i) =>
              <li
                key={c.id}
                className={cn(
                  'grid grid-cols-[1fr_auto_1fr] items-center gap-3 px-3.5 py-2.5',
                  i > 0 && 'border-t border-white/[0.045]'
                )}>
                
                  <span className="truncate font-mono text-[11.5px] text-ink-dim">{c.from}</span>
                  <ArrowRightIcon className="h-3 w-3 shrink-0 text-ink-ghost" strokeWidth={2.2} />
                  <span className="flex min-w-0 items-center gap-2">
                    <span
                    className={cn(
                      'truncate font-mono text-[11.5px]',
                      op.destructive ? 'text-danger-400 line-through' : 'text-jade-300'
                    )}>
                    
                      {c.to}
                    </span>
                    <span className="shrink-0 text-xs text-ink-ghost">{c.note}</span>
                    {(stage === 'executing' || stage === 'verified') &&
                  <CheckCircle2Icon
                    className={cn(
                      'ml-auto h-3.5 w-3.5 shrink-0',
                      stage === 'verified' ? 'text-jade-400' : 'text-ink-ghost'
                    )}
                    strokeWidth={2} />

                  }
                  </span>
                </li>
              )}
            </ul>
          </section>

          {/* Stage-specific action rail */}
          <AnimatePresence mode="wait" initial={false}>
            {(stage === 'proposed' || stage === 'review' || stage === 'confirm') &&
            <motion.section
              key="confirm"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
              className={cn(
                'mt-4 rounded-xl p-4',
                op.destructive ?
                'bg-danger-900/40 shadow-[inset_0_0_0_1px_rgba(244,101,91,0.28)]' :
                'bg-surface-raised shadow-ring'
              )}>
              
                {op.destructive ?
              <div className="flex items-start gap-3">
                    <ShieldAlertIcon
                  className="mt-0.5 h-4 w-4 shrink-0 text-danger-500"
                  strokeWidth={2} />
                
                    <div className="flex-1">
                      <p className="text-base font-medium text-danger-400">
                        This permanently deletes 6 files from disk
                      </p>
                      <p className="mt-1 text-base leading-[20px] text-ink-faint">
                        Originals are preserved. Deleted copies cannot be recovered from LocalMind.
                      </p>
                      <label className="mt-3 flex w-fit cursor-pointer items-center gap-2 text-base text-ink-dim">
                        <input
                      type="checkbox"
                      checked={ack}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setAck(checked);
                        if (checked && stage === 'review') setStage('confirm');
                        if (!checked && stage === 'confirm') setStage('review');
                      }}
                      className="h-3.5 w-3.5 appearance-none rounded-[3px] bg-white/[0.07] shadow-[inset_0_0_0_1px_rgba(244,101,91,0.4)] transition-colors duration-150 checked:bg-danger-500" />
                    
                        I understand this cannot be undone
                      </label>
                    </div>
                  </div> :

              <p className="text-base leading-[20px] text-ink-faint">
                    Nothing has been written yet. Confirming applies all {op.changes.length} changes
                    and re-points every affected index chunk.
                  </p>
              }

                <div className="mt-4 flex items-center gap-2">
                  <Button
                  variant={op.destructive ? 'danger' : 'primary'}
                  onClick={() => setStage(nextStage)}
                  disabled={blocked}>
                  
                    {stage === 'proposed' ?
                  `Review ${op.changes.length} changes` :
                  op.destructive ?
                  'Delete 6 files' :
                  stage === 'review' ?
                  'Changes look right — continue' :
                  `Confirm & apply ${op.changes.length} changes`}
                  </Button>
                  <Button variant="ghost">Discard action</Button>
                  <div className="flex-1" />
                  <span className="font-mono text-[10px] text-ink-ghost">
                    rollback retained 7 days
                  </span>
                </div>
              </motion.section>
            }

            {stage === 'executing' &&
            <motion.section
              key="executing"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
              className="mt-4 rounded-xl bg-surface-raised p-4 shadow-ring">
              
                <div className="flex items-center justify-between">
                  <p className="text-base font-medium text-ink">Applying changes…</p>
                  <span className="font-mono text-[10.5px] text-ink-faint">
                    writing · updating index
                  </span>
                </div>
                <Meter value={0.72} tone="info" className="mt-3" />
                <p className="mt-2.5 font-mono text-[10.5px] text-ink-ghost">
                  {op.id} · filesystem lock held · verifying checksums after write
                </p>
              </motion.section>
            }

            {stage === 'verified' &&
            <motion.section
              key="verified"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
              className="mt-4 rounded-xl bg-jade-900/40 p-4 shadow-[inset_0_0_0_1px_rgba(22,192,140,0.26)]">
              
                <div className="flex items-start gap-3">
                  <CheckCircle2Icon
                  className="mt-0.5 h-4 w-4 shrink-0 text-jade-400"
                  strokeWidth={2} />
                
                  <div className="flex-1">
                    <p className="text-base font-medium text-jade-300">
                      Verified — {op.changes.length} of {op.changes.length} changes applied
                    </p>
                    <p className="mt-1 text-base leading-[20px] text-ink-dim">
                      Checksums matched on every file and 96 index chunks were re-pointed. The
                      action is recorded in Activity.
                    </p>
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-2">
                  <Button
                  variant="secondary"
                  icon={<UndoIcon className="h-3.5 w-3.5" strokeWidth={1.9} />}>
                  
                    Undo operation
                  </Button>
                  <Button
                  variant="ghost"
                  icon={<RotateCcwIcon className="h-3.5 w-3.5" strokeWidth={1.9} />}
                  onClick={() => {
                    setStage('proposed');
                    setAck(false);
                  }}>
                  
                    Replay from proposal
                  </Button>
                  <div className="flex-1" />
                  <span className="font-mono text-[10px] text-jade-700">
                    token {op.id}-rb
                  </span>
                </div>
              </motion.section>
            }
          </AnimatePresence>
        </div>
      </div>
    </div>);

}