import React, { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  CheckCircle2Icon,
  ColumnsIcon,
  DatabaseIcon,
  FilePlus2Icon,
  FolderInputIcon,
  PencilLineIcon,
  SearchIcon,
  TextQuoteIcon } from
'lucide-react';
import type { ActivityKind } from '../../types';
import { activity } from '../../data/activity';
import { Badge } from '../ui/Badge';
import { SectionLabel } from '../ui/Panel';
import { cn } from '../../utils/cn';

const kindConfig: Record<
  ActivityKind,
  {icon: typeof SearchIcon;label: string;fg: string;bg: string;}> =
{
  indexed: { icon: DatabaseIcon, label: 'Indexed', fg: 'text-info-400', bg: 'bg-info-900' },
  searched: { icon: SearchIcon, label: 'Searched', fg: 'text-ink-dim', bg: 'bg-white/[0.05]' },
  summarized: {
    icon: TextQuoteIcon,
    label: 'Summarized',
    fg: 'text-jade-300',
    bg: 'bg-jade-900/70'
  },
  compared: { icon: ColumnsIcon, label: 'Compared', fg: 'text-jade-300', bg: 'bg-jade-900/70' },
  created: { icon: FilePlus2Icon, label: 'Created', fg: 'text-warn-400', bg: 'bg-warn-900' },
  moved: { icon: FolderInputIcon, label: 'Moved', fg: 'text-warn-400', bg: 'bg-warn-900' },
  renamed: { icon: PencilLineIcon, label: 'Renamed', fg: 'text-warn-400', bg: 'bg-warn-900' },
  verified: {
    icon: CheckCircle2Icon,
    label: 'Verified',
    fg: 'text-jade-300',
    bg: 'bg-jade-900/70'
  }
};

const filters: {id: 'all' | 'reads' | 'writes';label: string;kinds: ActivityKind[];}[] = [
{ id: 'all', label: 'All events', kinds: [] },
{ id: 'reads', label: 'Reads', kinds: ['indexed', 'searched', 'summarized', 'compared'] },
{ id: 'writes', label: 'Writes', kinds: ['created', 'moved', 'renamed', 'verified'] }];


export function ActivityView() {
  const [filter, setFilter] = useState<'all' | 'reads' | 'writes'>('all');

  const grouped = useMemo(() => {
    const active = filters.find((f) => f.id === filter)!;
    const events = filter === 'all' ? activity : activity.filter((e) => active.kinds.includes(e.kind));
    return events.reduce<Record<string, typeof activity>>((acc, e) => {
      acc[e.day] = acc[e.day] ? [...acc[e.day], e] : [e];
      return acc;
    }, {});
  }, [filter]);

  return (
    <div className="min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto max-w-[860px] px-8 py-8">
        <motion.header
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.24, ease: [0.23, 1, 0.32, 1] }}
          className="flex flex-wrap items-end justify-between gap-4">
          
          <div>
            <h1 className="font-display text-2xl font-semibold text-ink">Activity</h1>
            <p className="mt-1 text-base text-ink-faint">
              Every read and write LocalMind performed on your authorized folders, in order.
            </p>
          </div>
          <div className="flex items-center gap-0.5 rounded-lg bg-white/[0.04] p-0.5">
            {filters.map((f) =>
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id)}
              aria-pressed={filter === f.id}
              className={cn(
                'rounded-md px-2.5 py-1 text-sm font-medium transition-colors duration-150 ease-swift',
                filter === f.id ?
                'bg-surface-high text-ink shadow-soft' :
                'text-ink-faint hover:text-ink'
              )}>
              
                {f.label}
              </button>
            )}
          </div>
        </motion.header>

        <div className="mt-8 space-y-8">
          {Object.entries(grouped).map(([day, events]) =>
          <section key={day}>
              <SectionLabel
              className="mb-3"
              action={<span className="font-mono text-[10px] text-ink-ghost">{events.length} events</span>}>
              
                {day}
              </SectionLabel>
              <ol className="relative">
                <span className="absolute left-[13px] top-2 h-[calc(100%-1.5rem)] w-px bg-white/[0.06]" />
                {events.map((e, i) => {
                const { icon: Icon, label, fg, bg } = kindConfig[e.kind];
                return (
                  <motion.li
                    key={e.id}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                      duration: 0.22,
                      delay: Math.min(i * 0.035, 0.2),
                      ease: [0.23, 1, 0.32, 1]
                    }}
                    className="group relative flex gap-3.5 rounded-lg py-2.5 pl-0 pr-2 transition-colors duration-150 ease-swift hover:bg-white/[0.025]">
                    
                      <span
                      className={cn(
                        'relative z-10 mt-0.5 inline-flex h-[27px] w-[27px] shrink-0 items-center justify-center rounded-lg',
                        bg
                      )}>
                      
                        <Icon className={cn('h-3.5 w-3.5', fg)} strokeWidth={1.9} />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="truncate text-md font-medium tracking-[-0.01em] text-ink">
                            {e.title}
                          </h4>
                          <Badge tone="neutral">{label}</Badge>
                        </div>
                        <p className="mt-0.5 text-base leading-[20px] text-ink-faint">{e.detail}</p>
                        {e.target &&
                      <p className="mt-1 font-mono text-[10px] text-ink-ghost">{e.target}</p>
                      }
                      </div>
                      <span className="mt-1 shrink-0 font-mono text-[10.5px] text-ink-ghost">
                        {e.time}
                      </span>
                    </motion.li>);

              })}
              </ol>
            </section>
          )}
        </div>
      </div>
    </div>);

}