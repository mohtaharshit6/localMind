import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ChevronDownIcon, QuoteIcon } from 'lucide-react';
import type { Source } from '../../types';
import { FileIcon } from '../ui/FileIcon';
import { cn } from '../../utils/cn';

export function SourceCard({ source, index }: {source: Source;index: number;}) {
  const [open, setOpen] = useState(false);

  return (
    <div
      className={cn(
        'overflow-hidden rounded-lg bg-surface-raised shadow-ring',
        'transition-[background-color,box-shadow] duration-150 ease-swift',
        open ? 'bg-surface-high' : 'hover:bg-surface-high'
      )}>
      
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center gap-2.5 px-2.5 py-2 text-left">
        
        <span className="font-mono text-[10px] text-ink-ghost">{index + 1}</span>
        <FileIcon kind={source.kind} size="sm" />
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-medium text-ink-dim">
            {source.fileName}
          </span>
          <span className="block truncate font-mono text-[10px] text-ink-ghost">
            {source.location}
          </span>
        </span>
        <span className="shrink-0 font-mono text-[10px] text-jade-300">
          {Math.round(source.relevance * 100)}%
        </span>
        <ChevronDownIcon
          className={cn(
            'h-3.5 w-3.5 shrink-0 text-ink-ghost transition-transform duration-200 ease-swift',
            open && 'rotate-180'
          )}
          strokeWidth={2} />
        
      </button>
      <AnimatePresence initial={false}>
        {open &&
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
          className="overflow-hidden">
          
            <div className="mx-2.5 mb-2.5 flex gap-2 rounded-md bg-void/60 p-2.5">
              <QuoteIcon className="mt-0.5 h-3 w-3 shrink-0 text-jade-700" strokeWidth={2.2} />
              <p className="text-sm leading-5 text-ink-dim">{source.evidence}</p>
            </div>
          </motion.div>
        }
      </AnimatePresence>
    </div>);

}