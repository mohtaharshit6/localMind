import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  ArrowRightIcon,
  BarChart3Icon,
  ColumnsIcon,
  SearchIcon,
  SparklesIcon } from
'lucide-react';
import type { ChatMessage, PromptSuggestion } from '../../types';
import { promptSuggestions, systemStatus } from '../../data/workspace';
import { Message } from './Message';
import { Composer } from './Composer';
import { cn } from '../../utils/cn';

const intentIcon = {
  ask: SearchIcon,
  compare: ColumnsIcon,
  csv: BarChart3Icon,
  files: SparklesIcon
};

function SuggestionRow({
  suggestion,
  onPick,
  index




}: {suggestion: PromptSuggestion;onPick: (s: PromptSuggestion) => void;index: number;}) {
  const Icon = intentIcon[suggestion.intent];
  return (
    <motion.button
      type="button"
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.24, delay: 0.06 + index * 0.045, ease: [0.23, 1, 0.32, 1] }}
      onClick={() => onPick(suggestion)}
      className={cn(
        'group flex w-full items-center gap-3 px-2 py-2.5 text-left',
        'transition-colors duration-150 ease-swift hover:bg-white/[0.035]',
        'first:rounded-t-lg last:rounded-b-lg'
      )}>
      
      <Icon
        className="h-3.5 w-3.5 shrink-0 text-ink-faint transition-colors duration-150 group-hover:text-jade-300"
        strokeWidth={1.9} />
      
      <span className="min-w-0 flex-1 truncate text-md text-ink-dim transition-colors duration-150 group-hover:text-ink">
        {suggestion.label}
      </span>
      <span className="hidden shrink-0 font-mono text-[10.5px] text-ink-ghost sm:block">
        {suggestion.scope}
      </span>
      <ArrowRightIcon
        className="h-3.5 w-3.5 shrink-0 text-ink-ghost opacity-0 transition-[opacity,transform] duration-150 ease-swift group-hover:translate-x-0.5 group-hover:opacity-100"
        strokeWidth={2} />
      
    </motion.button>);

}

function Hero({ onPick }: {onPick: (s: PromptSuggestion) => void;}) {
  return (
    <div className="mx-auto flex h-full max-w-[820px] flex-col justify-center px-6 py-10">
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.28, ease: [0.23, 1, 0.32, 1] }}>
        
        <span className="inline-flex items-center gap-1.5 font-mono text-[10.5px] uppercase tracking-[0.12em] text-jade-300">
          <span className="h-1 w-1 rounded-full bg-jade-400" />
          {systemStatus.filesIndexed} files indexed · on-device
        </span>
        <h1 className="mt-4 font-display text-4xl font-semibold text-ink">
          Your files, understood.
        </h1>
        <p className="mt-3 max-w-[560px] text-md leading-[25px] text-ink-faint">
          Ask questions, explore documents, compare information and take action — all within your
          authorized workspace.
        </p>
      </motion.div>

      <div className="mt-9">
        <div className="mb-1.5 flex items-center gap-2 px-2">
          <h2 className="text-2xs font-semibold uppercase text-ink-faint">Start here</h2>
          <span className="h-px flex-1 bg-white/[0.06]" />
        </div>
        <div className="divide-y divide-white/[0.045]">
          {promptSuggestions.map((s, i) =>
          <SuggestionRow key={s.id} suggestion={s} onPick={onPick} index={i} />
          )}
        </div>
      </div>
    </div>);

}

export function AskView({
  messages,
  streamingId,
  onSubmit




}: {messages: ChatMessage[];streamingId: string | null;onSubmit: (text: string) => void;}) {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages.length]);

  const empty = messages.length === 0;

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="min-h-0 flex-1 overflow-y-auto">
        {empty ?
        <Hero onPick={(s) => onSubmit(s.label)} /> :

        <div className="mx-auto max-w-[820px] space-y-8 px-6 py-8">
            {messages.map((m) =>
          <Message key={m.id} message={m} stream={m.id === streamingId} />
          )}
            <div ref={endRef} />
          </div>
        }
      </div>
      <Composer onSubmit={onSubmit} busy={Boolean(streamingId)} />
    </div>);

}