import React, { useState } from 'react';
import { ArrowUpIcon, AtSignIcon, CpuIcon, FolderIcon, PaperclipIcon } from 'lucide-react';
import { systemStatus } from '../../data/workspace';
import { cn } from '../../utils/cn';

export function Composer({
  onSubmit,
  busy



}: {onSubmit: (text: string) => void;busy: boolean;}) {
  const [value, setValue] = useState('');

  const send = () => {
    const text = value.trim();
    if (!text || busy) return;
    onSubmit(text);
    setValue('');
  };

  return (
    <div className="glass hairline-t px-6 py-3.5">
      <div className="mx-auto max-w-[820px]">
        <div
          className={cn(
            'rounded-xl bg-surface-raised shadow-ring transition-shadow duration-200 ease-swift',
            'focus-within:shadow-jade'
          )}>
          
          <label htmlFor="composer" className="sr-only">
            Ask about your files
          </label>
          <textarea
            id="composer"
            rows={2}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            placeholder="Ask anything about your authorized files…"
            className="w-full resize-none bg-transparent px-3.5 pt-3 text-md leading-[22px] text-ink placeholder:text-ink-faint focus:outline-none" />
          
          <div className="flex items-center gap-1.5 px-2.5 pb-2.5">
            <button
              type="button"
              className="flex items-center gap-1.5 rounded-md bg-white/[0.04] px-2 py-1 text-xs text-ink-dim transition-colors duration-150 ease-swift hover:bg-white/[0.07] hover:text-ink">
              
              <FolderIcon className="h-3 w-3" strokeWidth={2} />
              {systemStatus.sources} folders · {systemStatus.filesIndexed} files
            </button>
            <button
              type="button"
              aria-label="Mention a file"
              className="flex h-6 w-6 items-center justify-center rounded-md text-ink-faint transition-colors duration-150 ease-swift hover:bg-white/[0.05] hover:text-ink">
              
              <AtSignIcon className="h-3.5 w-3.5" strokeWidth={2} />
            </button>
            <button
              type="button"
              aria-label="Attach a file"
              className="flex h-6 w-6 items-center justify-center rounded-md text-ink-faint transition-colors duration-150 ease-swift hover:bg-white/[0.05] hover:text-ink">
              
              <PaperclipIcon className="h-3.5 w-3.5" strokeWidth={2} />
            </button>
            <div className="flex-1" />
            <span className="flex items-center gap-1.5 font-mono text-[10px] text-ink-ghost">
              <CpuIcon className="h-3 w-3" strokeWidth={2} />
              {systemStatus.llm.name} · local
            </span>
            <button
              type="button"
              onClick={send}
              disabled={!value.trim() || busy}
              aria-label="Send message"
              className={cn(
                'ml-1.5 flex h-7 w-7 items-center justify-center rounded-md transition-[background-color,color,opacity] duration-150 ease-swift',
                value.trim() && !busy ?
                'bg-jade-500 text-void hover:bg-jade-400' :
                'bg-white/[0.06] text-ink-ghost'
              )}>
              
              <ArrowUpIcon className="h-4 w-4" strokeWidth={2.4} />
            </button>
          </div>
        </div>
        <p className="mt-2 text-center text-xs text-ink-ghost">
          Enter to send · Shift + Enter for a new line · answers cite the files they came from
        </p>
      </div>
    </div>);

}