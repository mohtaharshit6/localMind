import React from 'react';
import { motion } from 'framer-motion';
import { CopyIcon, RotateCcwIcon, ThumbsUpIcon } from 'lucide-react';
import type { ChatMessage } from '../../types';
import { BrainMark } from '../ui/Logo';
import { SourceCard } from './SourceCard';
import { useStreamedText } from '../../hooks/useStreamedText';
import { cn } from '../../utils/cn';

function Paragraphs({ text, streaming }: {text: string;streaming: boolean;}) {
  const parts = text.split('\n\n');
  return (
    <div className="space-y-3">
      {parts.map((p, i) =>
      <p
        key={i}
        className={cn(
          'text-md leading-[25px] text-ink-dim',
          i === 0 && 'text-ink',
          streaming && i === parts.length - 1 && 'caret'
        )}>
        
          {p}
        </p>
      )}
    </div>);

}

export function Message({ message, stream }: {message: ChatMessage;stream: boolean;}) {
  const { visible, streaming } = useStreamedText(message.text, stream && message.role === 'assistant');

  if (message.role === 'user') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
        className="flex justify-end">
        
        <div className="max-w-[76%] rounded-2xl rounded-br-md bg-surface-high px-4 py-2.5 shadow-ring">
          <p className="text-md leading-[24px] text-ink">{message.text}</p>
        </div>
      </motion.div>);

  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
      className="flex gap-3">
      
      <span className="mt-0.5 inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-jade-900 text-jade-300 shadow-[inset_0_0_0_1px_rgba(53,214,164,0.2)]">
        <BrainMark className="h-4 w-4" />
      </span>
      <div className="min-w-0 flex-1">
        <Paragraphs text={visible} streaming={streaming} />

        {!streaming && message.sources && message.sources.length > 0 &&
        <div className="mt-4">
            <div className="mb-2 flex items-center gap-2">
              <h4 className="text-2xs font-semibold uppercase text-ink-faint">
                Sources · {message.sources.length}
              </h4>
              <span className="h-px flex-1 bg-white/[0.06]" />
            </div>
            <div className="grid gap-1.5 lg:grid-cols-2">
              {message.sources.map((s, i) =>
            <SourceCard key={s.id} source={s} index={i} />
            )}
            </div>
          </div>
        }

        {!streaming &&
        <div className="mt-3 flex items-center gap-1">
            {[
          { icon: CopyIcon, label: 'Copy answer' },
          { icon: RotateCcwIcon, label: 'Regenerate' },
          { icon: ThumbsUpIcon, label: 'Good answer' }].
          map(({ icon: Icon, label }) =>
          <button
            key={label}
            type="button"
            aria-label={label}
            className="flex h-6 w-6 items-center justify-center rounded-md text-ink-ghost transition-colors duration-150 ease-swift hover:bg-white/[0.05] hover:text-ink-dim">
            
                <Icon className="h-3.5 w-3.5" strokeWidth={1.9} />
              </button>
          )}
            {message.latencyMs &&
          <span className="ml-2 font-mono text-[10px] text-ink-ghost">
                {message.latencyMs}ms · {message.tokens} tok · local
              </span>
          }
          </div>
        }
      </div>
    </motion.div>);

}