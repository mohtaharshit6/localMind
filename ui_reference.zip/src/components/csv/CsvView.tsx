import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis } from
'recharts';
import {
  ArrowUpIcon,
  LightbulbIcon,
  SendHorizonalIcon,
  TrendingDownIcon,
  TrendingUpIcon } from
'lucide-react';
import {
  dataset,
  headlineMetric,
  insights,
  monthlyTrend,
  csvQuestions,
  regionRevenue,
  secondaryMetrics } from
'../../data/csv';
import { FileIcon } from '../ui/FileIcon';
import { Badge } from '../ui/Badge';
import { Meter, SectionLabel } from '../ui/Panel';
import { cn } from '../../utils/cn';

const axisStyle = { fill: '#6A7178', fontSize: 10, fontFamily: 'JetBrains Mono' };

function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg bg-surface-high px-2.5 py-2 shadow-lift">
      <p className="font-mono text-[10px] uppercase text-ink-ghost">{label}</p>
      {payload.map((p: any) =>
      <p key={p.dataKey} className="mt-0.5 text-sm text-ink">
          <span className="text-ink-faint">{p.name}: </span>
          {typeof p.value === 'number' && p.value > 100 ?
        `$${(p.value / 1000).toFixed(2)}M` :
        `${p.value}%`}
        </p>
      )}
    </div>);

}

export function CsvView() {
  const [question, setQuestion] = useState('');
  const maxRevenue = Math.max(...regionRevenue.map((r) => r.revenue));

  return (
    <div className="min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto max-w-[1040px] px-8 py-8">
        <motion.header
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.24, ease: [0.23, 1, 0.32, 1] }}
          className="flex flex-wrap items-start justify-between gap-4">
          
          <div className="flex items-start gap-3.5">
            <FileIcon kind="csv" />
            <div>
              <h1 className="font-display text-2xl font-semibold text-ink">{dataset.name}</h1>
              <p className="mt-1 font-mono text-[11px] text-ink-ghost">
                {dataset.folder} · {dataset.rows.toLocaleString()} rows × {dataset.columns} columns ·{' '}
                {dataset.sizeLabel}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge tone="jade">{Math.round(dataset.quality * 100)}% complete</Badge>
            <Badge tone="warn">{dataset.nullCells} null cells</Badge>
          </div>
        </motion.header>

        {/* Headline metric outweighs the supporting ones instead of a tile grid */}
        <section className="mt-6 grid gap-3 lg:grid-cols-[1.15fr_2fr]">
          <div className="rounded-xl bg-surface-raised p-5 shadow-ring">
            <p className="text-2xs font-semibold uppercase text-ink-faint">
              {headlineMetric.label}
            </p>
            <div className="mt-2 flex items-end gap-2.5">
              <span className="font-display text-4xl font-semibold text-ink">
                {headlineMetric.value}
              </span>
              <span className="mb-1.5 inline-flex items-center gap-0.5 rounded-md bg-jade-900/70 px-1.5 py-0.5 font-mono text-[11px] text-jade-300">
                <ArrowUpIcon className="h-3 w-3" strokeWidth={2.6} />
                {headlineMetric.delta}
              </span>
            </div>
            <p className="mt-1.5 text-base text-ink-faint">
              {headlineMetric.deltaLabel} · 6 regions, 84 reps
            </p>
            <Meter value={0.842} className="mt-4" />
            <p className="mt-2 font-mono text-[10px] text-ink-ghost">84% of $10M quarter target</p>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-4">
            {secondaryMetrics.map((m) =>
            <div key={m.label} className="rounded-xl bg-surface-raised/70 p-3.5 shadow-ring">
                <p className="truncate text-2xs font-semibold uppercase text-ink-ghost">
                  {m.label}
                </p>
                <p className="mt-1.5 font-display text-xl font-semibold text-ink">{m.value}</p>
                <p
                className={cn(
                  'mt-0.5 flex items-center gap-1 font-mono text-[10.5px]',
                  m.positive ? 'text-jade-300' : 'text-danger-400'
                )}>
                
                  {m.positive ?
                <TrendingUpIcon className="h-3 w-3" strokeWidth={2.2} /> :

                <TrendingDownIcon className="h-3 w-3" strokeWidth={2.2} />
                }
                  {m.delta}
                </p>
              </div>
            )}
          </div>
        </section>

        {/* Charts */}
        <section className="mt-4 grid gap-3 lg:grid-cols-2">
          <div className="rounded-xl bg-surface-raised p-4 shadow-ring">
            <SectionLabel
              className="mb-4"
              action={
              <span className="font-mono text-[10px] text-ink-ghost">revenue · $K</span>
              }>
              
              Revenue by region
            </SectionLabel>
            <div className="h-[196px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={regionRevenue} margin={{ top: 4, right: 4, bottom: 0, left: -18 }}>
                  <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
                  <XAxis dataKey="region" tick={axisStyle} axisLine={false} tickLine={false} />
                  <YAxis tick={axisStyle} axisLine={false} tickLine={false} width={44} />
                  <Tooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
                  <Bar
                    dataKey="revenue"
                    name="Revenue"
                    fill="#16C08C"
                    radius={[3, 3, 0, 0]}
                    maxBarSize={30} />
                  
                </BarChart>
              </ResponsiveContainer>
            </div>
            <ul className="mt-3 space-y-1.5 border-t border-white/[0.055] pt-3">
              {regionRevenue.slice(0, 3).map((r) =>
              <li key={r.region} className="flex items-center gap-2.5">
                  <span className="w-14 shrink-0 text-sm text-ink-dim">{r.region}</span>
                  <Meter value={r.revenue / maxRevenue} className="flex-1" />
                  <span className="w-16 shrink-0 text-right font-mono text-[10.5px] text-ink-faint">
                    {r.margin}% mgn
                  </span>
                </li>
              )}
            </ul>
          </div>

          <div className="rounded-xl bg-surface-raised p-4 shadow-ring">
            <SectionLabel
              className="mb-4"
              action={
              <span className="flex items-center gap-3 font-mono text-[10px] text-ink-ghost">
                  <span className="flex items-center gap-1">
                    <span className="h-px w-3 bg-jade-400" />
                    actual
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="h-px w-3 bg-ink-ghost" />
                    forecast
                  </span>
                </span>
              }>
              
              Monthly trend
            </SectionLabel>
            <div className="h-[196px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyTrend} margin={{ top: 4, right: 4, bottom: 0, left: -18 }}>
                  <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
                  <XAxis dataKey="month" tick={axisStyle} axisLine={false} tickLine={false} />
                  <YAxis tick={axisStyle} axisLine={false} tickLine={false} width={44} />
                  <Tooltip content={<ChartTooltip />} cursor={{ stroke: 'rgba(255,255,255,0.1)' }} />
                  <Line
                    type="monotone"
                    dataKey="forecast"
                    name="Forecast"
                    stroke="#484E55"
                    strokeWidth={1.5}
                    strokeDasharray="3 3"
                    dot={false} />
                  
                  <Line
                    type="monotone"
                    dataKey="revenue"
                    name="Revenue"
                    stroke="#35D6A4"
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 3, fill: '#35D6A4', stroke: '#08090A', strokeWidth: 2 }} />
                  
                </LineChart>
              </ResponsiveContainer>
            </div>
            <p className="mt-3 border-t border-white/[0.055] pt-3 text-base leading-[20px] text-ink-faint">
              September closed 1.4% above forecast, the third consecutive month ahead of plan.
            </p>
          </div>
        </section>

        {/* Natural language question */}
        <section className="mt-4 rounded-xl bg-surface-raised p-4 shadow-ring">
          <SectionLabel className="mb-3">Ask this dataset</SectionLabel>
          <div className="flex items-center gap-2 rounded-lg bg-void/60 px-3 py-2 shadow-ring transition-shadow duration-200 ease-swift focus-within:shadow-jade">
            <label htmlFor="csv-q" className="sr-only">
              Ask a question about this dataset
            </label>
            <input
              id="csv-q"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="e.g. Which segment lost the most margin this quarter?"
              className="flex-1 bg-transparent text-md text-ink placeholder:text-ink-faint focus:outline-none" />
            
            <button
              type="button"
              aria-label="Run question"
              className={cn(
                'flex h-7 w-7 items-center justify-center rounded-md transition-colors duration-150 ease-swift',
                question.trim() ?
                'bg-jade-500 text-void hover:bg-jade-400' :
                'bg-white/[0.06] text-ink-ghost'
              )}>
              
              <SendHorizonalIcon className="h-3.5 w-3.5" strokeWidth={2.2} />
            </button>
          </div>
          <div className="mt-2.5 flex flex-wrap gap-1.5">
            {csvQuestions.map((q) =>
            <button
              key={q}
              type="button"
              onClick={() => setQuestion(q)}
              className="rounded-md bg-white/[0.04] px-2 py-1 text-sm text-ink-dim transition-colors duration-150 ease-swift hover:bg-white/[0.08] hover:text-ink">
              
                {q}
              </button>
            )}
          </div>
        </section>

        {/* Insights */}
        <section className="mt-9 pb-4">
          <SectionLabel className="mb-2.5">Generated insights</SectionLabel>
          <ul className="divide-y divide-white/[0.045]">
            {insights.map((i) =>
            <li key={i.id} className="group flex items-start gap-3.5 py-3.5">
                <span className="mt-0.5 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-jade-900/70 text-jade-300">
                  <LightbulbIcon className="h-3.5 w-3.5" strokeWidth={1.9} />
                </span>
                <div className="min-w-0 flex-1">
                  <h4 className="text-md font-medium tracking-[-0.01em] text-ink">{i.title}</h4>
                  <p className="mt-1 max-w-[720px] text-base leading-[21px] text-ink-faint">
                    {i.detail}
                  </p>
                </div>
                <div className="hidden shrink-0 gap-1 pt-0.5 sm:flex">
                  {i.columns.map((c) =>
                <Badge key={c} mono>
                      {c}
                    </Badge>
                )}
                </div>
              </li>
            )}
          </ul>
        </section>
      </div>
    </div>);

}