import React from 'react';
import { motion } from 'framer-motion';
import { AlertTriangleIcon, ArrowRightIcon, EqualIcon, QuoteIcon } from 'lucide-react';
import { compareDocs } from '../../data/documents';
import { FileIcon } from '../ui/FileIcon';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { SectionLabel } from '../ui/Panel';
import { cn } from '../../utils/cn';

function DocPanel({
  doc,
  label,
  tone




}: {doc: typeof compareDocs.left.meta;label: string;tone: 'left' | 'right';}) {
  return (
    <div
      className={cn(
        'rounded-xl bg-surface-raised p-4 shadow-ring',
        tone === 'right' && 'bg-surface-high'
      )}>
      
      <div className="flex items-center justify-between">
        <span className="font-mono text-[10px] uppercase tracking-[0.1em] text-ink-ghost">
          {label}
        </span>
        <Badge tone={tone === 'right' ? 'jade' : 'neutral'} mono>
          {tone === 'right' ? 'current' : 'baseline'}
        </Badge>
      </div>
      <div className="mt-3 flex items-start gap-3">
        <FileIcon kind={doc.kind} />
        <div className="min-w-0">
          <h3 className="truncate text-lg font-medium tracking-[-0.015em] text-ink">{doc.name}</h3>
          <p className="mt-0.5 truncate font-mono text-[10.5px] text-ink-ghost">{doc.folder}</p>
        </div>
      </div>
      <dl className="mt-4 grid grid-cols-2 gap-y-2 border-t border-white/[0.055] pt-3">
        {[
        ['Extent', doc.pages],
        ['Length', doc.words],
        ['Modified', doc.modified],
        ['Indexed', doc.indexed]].
        map(([k, v]) =>
        <div key={k} className="flex flex-col">
            <dt className="text-2xs font-semibold uppercase text-ink-ghost">{k}</dt>
            <dd className="mt-0.5 text-sm text-ink-dim">{v}</dd>
          </div>
        )}
      </dl>
    </div>);

}

export function CompareView() {
  const { left, right, similarities, differences, evidence } = compareDocs;
  const risks = differences.filter((d) => d.severity === 'risk').length;

  return (
    <div className="min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto max-w-[960px] px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.24, ease: [0.23, 1, 0.32, 1] }}
          className="flex items-end justify-between gap-4">
          
          <div>
            <h1 className="font-display text-2xl font-semibold text-ink">Document comparison</h1>
            <p className="mt-1 text-base text-ink-faint">
              {similarities.length} similarities · {differences.length} differences ·{' '}
              <span className="text-danger-400">{risks} flagged as scope risk</span>
            </p>
          </div>
          <Button size="sm" variant="secondary">
            Swap documents
          </Button>
        </motion.div>

        <div className="mt-5 grid grid-cols-1 items-start gap-3 md:grid-cols-[1fr_auto_1fr]">
          <DocPanel doc={left.meta} label={left.label} tone="left" />
          <div className="hidden items-center justify-center self-center md:flex">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-surface-high text-ink-faint shadow-ring">
              <ArrowRightIcon className="h-3.5 w-3.5" strokeWidth={2} />
            </span>
          </div>
          <DocPanel doc={right.meta} label={right.label} tone="right" />
        </div>

        {/* Differences lead — they are what the user came for */}
        <section className="mt-10">
          <SectionLabel className="mb-3">Material differences</SectionLabel>
          <div className="overflow-hidden rounded-xl shadow-ring">
            <div className="hairline-b grid grid-cols-[168px_1fr_1fr] bg-surface-raised px-4 py-2">
              {['Topic', left.meta.name, right.meta.name].map((h, i) =>
              <span
                key={h}
                className={cn(
                  'truncate font-mono text-[10px] uppercase tracking-[0.08em]',
                  i === 2 ? 'text-jade-300' : 'text-ink-ghost'
                )}>
                
                  {h}
                </span>
              )}
            </div>
            <ul className="divide-y divide-white/[0.045] bg-surface-raised/60">
              {differences.map((d) =>
              <li
                key={d.id}
                className="group grid grid-cols-[168px_1fr_1fr] items-start gap-2 px-4 py-3 transition-colors duration-150 ease-swift hover:bg-white/[0.025]">
                
                  <div className="pr-3">
                    <p className="text-base font-medium text-ink">{d.topic}</p>
                    {d.severity === 'risk' &&
                  <span className="mt-1 inline-flex items-center gap-1 text-xs text-danger-400">
                        <AlertTriangleIcon className="h-2.5 w-2.5" strokeWidth={2.4} />
                        scope risk
                      </span>
                  }
                  </div>
                  <p className="text-base leading-[20px] text-ink-faint line-through decoration-white/20">
                    {d.left}
                  </p>
                  <div>
                    <p
                    className={cn(
                      'text-base leading-[20px]',
                      d.severity === 'risk' ? 'text-danger-400' : 'text-ink-dim'
                    )}>
                    
                      {d.right}
                    </p>
                    <p className="mt-1 text-xs leading-4 text-ink-ghost">{d.note}</p>
                  </div>
                </li>
              )}
            </ul>
          </div>
        </section>

        <div className="mt-10 grid gap-9 lg:grid-cols-[1fr_1fr]">
          <section>
            <SectionLabel className="mb-2.5">Unchanged</SectionLabel>
            <ul className="space-y-2.5">
              {similarities.map((s, i) =>
              <li key={i} className="flex items-start gap-2.5">
                  <EqualIcon
                  className="mt-1 h-3 w-3 shrink-0 text-ink-ghost"
                  strokeWidth={2.4} />
                
                  <p className="text-base leading-[21px] text-ink-faint">{s}</p>
                </li>
              )}
            </ul>
          </section>

          <section className="pb-4">
            <SectionLabel className="mb-2.5">Important evidence</SectionLabel>
            <div className="space-y-2">
              {evidence.map((e) =>
              <figure key={e.id} className="rounded-lg bg-surface-raised p-3 shadow-ring">
                  <blockquote className="flex gap-2">
                    <QuoteIcon className="mt-0.5 h-3 w-3 shrink-0 text-jade-700" strokeWidth={2.2} />
                    <p className="text-sm leading-[19px] text-ink-dim">{e.quote}</p>
                  </blockquote>
                  <figcaption className="mt-2 flex items-center gap-2 pl-5 font-mono text-[10px] text-ink-ghost">
                    <span className="truncate">{e.file}</span>
                    <span className="text-jade-700">·</span>
                    <span className="shrink-0">{e.location}</span>
                  </figcaption>
                </figure>
              )}
            </div>
          </section>
        </div>
      </div>
    </div>);

}