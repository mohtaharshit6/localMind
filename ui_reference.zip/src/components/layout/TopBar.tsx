import React from 'react';
import {
  ChevronRightIcon,
  PanelRightCloseIcon,
  PanelRightOpenIcon,
  SearchIcon,
  SettingsIcon,
  ShieldCheckIcon } from
'lucide-react';
import type { ViewId } from '../../types';
import { systemStatus, workspaceName } from '../../data/workspace';
import { StatusDot } from '../ui/StatusDot';
import { cn } from '../../utils/cn';

const viewTitles: Record<ViewId, string> = {
  ask: 'Ask',
  summarize: 'Summarize',
  compare: 'Compare',
  csv: 'CSV Analysis',
  files: 'File Operations',
  activity: 'Activity'
};

export function TopBar({
  view,
  contextOpen,
  onToggleContext




}: {view: ViewId;contextOpen: boolean;onToggleContext: () => void;}) {
  return (
    <header className="hairline-b glass sticky top-0 z-20 flex h-13 shrink-0 items-center gap-3 px-4">
      <div className="flex min-w-0 items-center gap-1.5">
        <button
          type="button"
          className="rounded-md px-1.5 py-1 text-base font-medium text-ink-dim transition-colors duration-150 ease-swift hover:bg-white/[0.04] hover:text-ink">
          
          {workspaceName}
        </button>
        <ChevronRightIcon className="h-3.5 w-3.5 shrink-0 text-ink-ghost" strokeWidth={2} />
        <span className="px-1.5 text-base font-medium text-ink">{viewTitles[view]}</span>
      </div>

      <div className="ml-1 flex items-center gap-1.5 rounded-md bg-jade-900/50 px-2 py-1">
        <StatusDot state="ready" pulse />
        <span className="font-mono text-[10.5px] uppercase tracking-[0.08em] text-jade-300">
          Indexed {systemStatus.filesIndexed}
        </span>
      </div>

      <div className="flex-1" />

      <button
        type="button"
        className={cn(
          'group flex h-8 w-[260px] items-center gap-2 rounded-lg bg-white/[0.035] px-2.5 shadow-ring',
          'transition-[background-color,box-shadow] duration-150 ease-swift hover:bg-white/[0.06]'
        )}>
        
        <SearchIcon className="h-3.5 w-3.5 shrink-0 text-ink-faint" strokeWidth={2} />
        <span className="flex-1 text-left text-base text-ink-faint">Search files & answers</span>
        <kbd className="rounded border-0 bg-white/[0.06] px-1.5 py-0.5 font-mono text-[10px] text-ink-faint">
          ⌘K
        </kbd>
      </button>

      <div className="mx-1 h-5 w-px bg-white/[0.07]" />

      <button
        type="button"
        aria-label="Local-only processing"
        title="All processing happens on this device"
        className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-faint transition-colors duration-150 ease-swift hover:bg-white/[0.04] hover:text-jade-300">
        
        <ShieldCheckIcon className="h-4 w-4" strokeWidth={1.9} />
      </button>
      <button
        type="button"
        aria-label={contextOpen ? 'Hide workspace context' : 'Show workspace context'}
        aria-pressed={contextOpen}
        onClick={onToggleContext}
        className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-faint transition-colors duration-150 ease-swift hover:bg-white/[0.04] hover:text-ink">
        
        {contextOpen ?
        <PanelRightCloseIcon className="h-4 w-4" strokeWidth={1.9} /> :

        <PanelRightOpenIcon className="h-4 w-4" strokeWidth={1.9} />
        }
      </button>
      <button
        type="button"
        aria-label="Settings"
        className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-faint transition-colors duration-150 ease-swift hover:bg-white/[0.04] hover:text-ink">
        
        <SettingsIcon className="h-4 w-4" strokeWidth={1.9} />
      </button>
      <button
        type="button"
        aria-label="Account"
        className="ml-0.5 flex h-7 w-7 items-center justify-center rounded-full bg-surface-high font-mono text-[10.5px] font-medium text-ink-dim shadow-ring transition-colors duration-150 ease-swift hover:text-ink">
        
        MK
      </button>
    </header>);

}