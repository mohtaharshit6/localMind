import React from 'react';
import { ActivitySquareIcon, LockIcon, RefreshCwIcon } from 'lucide-react';
import type { Source } from '../../types';
import { folders, recentlyIndexed, systemStatus } from '../../data/workspace';
import { FileIcon } from '../ui/FileIcon';
import { Meter, SectionLabel } from '../ui/Panel';
import { StatusDot } from '../ui/StatusDot';
import { Badge } from '../ui/Badge';

const statusState = {
  indexed: 'ready',
  indexing: 'working',
  paused: 'paused',
  error: 'error'
} as const;

export function ContextPanel({ sources }: {sources: Source[];}) {
  return (
    <aside
      aria-label="Workspace context"
      className="hairline-l hidden w-[304px] shrink-0 flex-col overflow-y-auto bg-surface/60 xl:flex">
      
      <div className="hairline-b flex h-13 items-center px-4">
        <h2 className="text-md font-medium tracking-[-0.01em] text-ink">Workspace Context</h2>
      </div>

      <div className="space-y-6 px-4 py-4">
        <div>
          <SectionLabel
            className="mb-2.5"
            action={
            <span className="flex items-center gap-1 font-mono text-[10px] text-ink-ghost">
                <LockIcon className="h-2.5 w-2.5" strokeWidth={2.2} />
                scoped
              </span>
            }>
            
            Authorized folders
          </SectionLabel>
          <ul className="space-y-2">
            {folders.map((f) =>
            <li key={f.id} className="flex items-start gap-2.5">
                <StatusDot
                state={statusState[f.status]}
                pulse={f.status === 'indexing'}
                className="mt-1.5" />
              
                <div className="min-w-0 flex-1">
                  <p className="truncate text-base text-ink-dim">{f.name}</p>
                  <p className="truncate font-mono text-[10.5px] text-ink-ghost">{f.path}</p>
                </div>
                <span className="mt-0.5 shrink-0 font-mono text-[10px] uppercase text-ink-ghost">
                  {f.permission === 'read' ? 'R' : 'RW'}
                </span>
              </li>
            )}
          </ul>
        </div>

        <div>
          <SectionLabel className="mb-2.5">Recently indexed</SectionLabel>
          <ul className="-mx-2">
            {recentlyIndexed.slice(0, 4).map((f) =>
            <li key={f.id}>
                <button
                type="button"
                className="group flex w-full items-center gap-2.5 rounded-md px-2 py-1.5 text-left transition-colors duration-150 ease-swift hover:bg-white/[0.035]">
                
                  <FileIcon kind={f.kind} size="sm" />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-base text-ink-dim transition-colors group-hover:text-ink">
                      {f.name}
                    </span>
                    <span className="block truncate font-mono text-[10px] text-ink-ghost">
                      {f.sizeLabel} · {f.chunks} chunks
                    </span>
                  </span>
                  <span className="shrink-0 font-mono text-[10px] text-ink-ghost">
                    {f.indexedAt}
                  </span>
                </button>
              </li>
            )}
          </ul>
        </div>

        <div>
          <SectionLabel className="mb-2.5">
            {sources.length ? 'Relevant sources' : 'Sources in scope'}
          </SectionLabel>
          {sources.length ?
          <ul className="space-y-1.5">
              {sources.map((s) =>
            <li
              key={s.id}
              className="rounded-lg bg-surface-raised p-2.5 shadow-ring transition-colors duration-150 ease-swift hover:bg-surface-high">
              
                  <div className="flex items-center gap-2">
                    <FileIcon kind={s.kind} size="sm" />
                    <span className="min-w-0 flex-1 truncate text-sm text-ink-dim">
                      {s.fileName}
                    </span>
                    <Badge tone="jade" mono>
                      {Math.round(s.relevance * 100)}
                    </Badge>
                  </div>
                  <p className="mt-1.5 font-mono text-[10.5px] text-ink-ghost">{s.location}</p>
                </li>
            )}
            </ul> :

          <p className="text-base leading-5 text-ink-ghost">
              Nothing retrieved yet. Sources appear here the moment a question touches your files.
            </p>
          }
        </div>

        <div>
          <SectionLabel className="mb-2.5">Index health</SectionLabel>
          <div className="rounded-lg bg-surface-raised p-3 shadow-ring">
            <div className="flex items-baseline justify-between">
              <span className="font-display text-xl font-semibold text-ink">
                {Math.round(systemStatus.indexHealth * 100)}%
              </span>
              <span className="font-mono text-[10.5px] text-ink-ghost">
                {systemStatus.chunks.toLocaleString()} chunks
              </span>
            </div>
            <Meter value={systemStatus.indexHealth} className="mt-2.5" />
            <dl className="mt-3 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <dt className="text-ink-faint">Embedder</dt>
                <dd className="font-mono text-[10.5px] text-ink-dim">{systemStatus.embedder}</dd>
              </div>
              <div className="flex items-center justify-between text-xs">
                <dt className="text-ink-faint">Stale files</dt>
                <dd className="font-mono text-[10.5px] text-warn-400">7 pending</dd>
              </div>
              <div className="flex items-center justify-between text-xs">
                <dt className="text-ink-faint">Last sweep</dt>
                <dd className="font-mono text-[10.5px] text-ink-dim">{systemStatus.lastSweep}</dd>
              </div>
            </dl>
            <button
              type="button"
              className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-md bg-white/[0.04] py-1.5 text-xs font-medium text-ink-dim transition-colors duration-150 ease-swift hover:bg-white/[0.075] hover:text-ink">
              
              <RefreshCwIcon className="h-3 w-3" strokeWidth={2} />
              Re-index stale files
            </button>
          </div>
        </div>

        <p className="flex items-start gap-2 text-xs leading-4 text-ink-ghost">
          <ActivitySquareIcon className="mt-px h-3 w-3 shrink-0" strokeWidth={2} />
          Every query, retrieval and write runs on this device. Nothing is uploaded.
        </p>
      </div>
    </aside>);

}