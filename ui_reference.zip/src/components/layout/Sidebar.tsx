import React from 'react';
import {
  ActivityIcon,
  BarChart3Icon,
  CheckIcon,
  ColumnsIcon,
  CpuIcon,
  DatabaseIcon,
  FolderPlusIcon,
  Loader2Icon,
  MessagesSquareIcon,
  PauseIcon,
  SparklesIcon,
  TextQuoteIcon,
  WrenchIcon } from
'lucide-react';
import type { ViewId } from '../../types';
import { folders, systemStatus, workspaceName } from '../../data/workspace';
import { Logo } from '../ui/Logo';
import { StatusDot } from '../ui/StatusDot';
import { Meter, SectionLabel } from '../ui/Panel';
import { cn } from '../../utils/cn';

const navItems: {id: ViewId;label: string;icon: typeof MessagesSquareIcon;hint?: string;}[] = [
{ id: 'ask', label: 'Ask', icon: MessagesSquareIcon, hint: '⌘1' },
{ id: 'summarize', label: 'Summarize', icon: TextQuoteIcon, hint: '⌘2' },
{ id: 'compare', label: 'Compare', icon: ColumnsIcon, hint: '⌘3' },
{ id: 'csv', label: 'CSV Analysis', icon: BarChart3Icon, hint: '⌘4' },
{ id: 'files', label: 'File Operations', icon: WrenchIcon, hint: '⌘5' },
{ id: 'activity', label: 'Activity', icon: ActivityIcon, hint: '⌘6' }];


function FolderRow({ name, count, status, progress




}: {name: string;count: number;status: string;progress?: number;}) {
  return (
    <button
      type="button"
      className="group -mx-2 flex w-[calc(100%+1rem)] flex-col gap-1 rounded-md px-2 py-1.5 text-left transition-colors duration-150 ease-swift hover:bg-white/[0.035]">
      
      <span className="flex items-center gap-2">
        {status === 'indexing' ?
        <Loader2Icon className="h-3 w-3 shrink-0 animate-spin text-info-400" strokeWidth={2} /> :
        status === 'paused' ?
        <PauseIcon className="h-3 w-3 shrink-0 text-ink-ghost" strokeWidth={2} /> :

        <CheckIcon className="h-3 w-3 shrink-0 text-jade-400" strokeWidth={2.4} />
        }
        <span className="min-w-0 flex-1 truncate text-base text-ink-dim transition-colors group-hover:text-ink">
          {name}
        </span>
        <span className="font-mono text-[10.5px] text-ink-ghost">{count}</span>
      </span>
      {typeof progress === 'number' && <Meter value={progress} tone="info" className="ml-5" />}
    </button>);

}

export function Sidebar({
  view,
  onChangeView



}: {view: ViewId;onChangeView: (v: ViewId) => void;}) {
  return (
    <nav
      aria-label="Primary"
      className="hairline-r flex w-[248px] shrink-0 flex-col bg-surface/80">
      
      <div className="flex h-13 items-center px-4">
        <Logo />
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {/* Workspace */}
        <SectionLabel className="mb-2.5 mt-1">Workspace</SectionLabel>
        <div className="mb-1 flex items-center gap-2 pb-1">
          <span className="text-md font-medium tracking-[-0.01em] text-ink">{workspaceName}</span>
        </div>
        <div className="mb-2 space-y-0.5">
          {folders.map((f) =>
          <FolderRow
            key={f.id}
            name={f.name}
            count={f.fileCount}
            status={f.status}
            progress={f.progress} />

          )}
        </div>
        <div className="flex flex-col gap-0.5">
          <button
            type="button"
            className="-mx-2 flex items-center gap-2 rounded-md px-2 py-1.5 text-base text-ink-faint transition-colors duration-150 ease-swift hover:bg-white/[0.035] hover:text-ink">
            
            <FolderPlusIcon className="h-3.5 w-3.5" strokeWidth={1.9} />
            Add folder
          </button>
          <button
            type="button"
            className="-mx-2 flex items-center gap-2 rounded-md px-2 py-1.5 text-base text-ink-faint transition-colors duration-150 ease-swift hover:bg-white/[0.035] hover:text-ink">
            
            <SparklesIcon className="h-3.5 w-3.5" strokeWidth={1.9} />
            Load demo data
          </button>
        </div>

        <div className="mt-4 rounded-lg bg-surface-raised px-3 py-2.5 shadow-ring">
          <div className="flex items-center justify-between">
            <span className="text-2xs font-semibold uppercase text-ink-faint">Index status</span>
            <span className="font-mono text-[10.5px] text-jade-300">
              {Math.round(systemStatus.indexHealth * 100)}%
            </span>
          </div>
          <Meter value={systemStatus.indexHealth} className="mt-2" />
          <p className="mt-2 text-xs text-ink-ghost">
            1 folder indexing · swept {systemStatus.lastSweep}
          </p>
        </div>

        {/* System */}
        <SectionLabel className="mb-2 mt-6">System</SectionLabel>
        <dl className="space-y-1.5">
          <div className="flex items-center justify-between">
            <dt className="flex items-center gap-2 text-base text-ink-faint">
              <DatabaseIcon className="h-3.5 w-3.5" strokeWidth={1.9} />
              Files indexed
            </dt>
            <dd className="font-mono text-[11.5px] text-ink-dim">{systemStatus.filesIndexed}</dd>
          </div>
          <div className="flex items-center justify-between">
            <dt className="flex items-center gap-2 text-base text-ink-faint">
              <FolderPlusIcon className="h-3.5 w-3.5" strokeWidth={1.9} />
              Sources
            </dt>
            <dd className="font-mono text-[11.5px] text-ink-dim">{systemStatus.sources} folders</dd>
          </div>
          <div className="flex items-center justify-between">
            <dt className="flex items-center gap-2 text-base text-ink-faint">
              <CpuIcon className="h-3.5 w-3.5" strokeWidth={1.9} />
              LLM
            </dt>
            <dd className="flex items-center gap-1.5">
              <StatusDot state="ready" pulse />
              <span className="font-mono text-[11.5px] text-jade-300">Ready</span>
            </dd>
          </div>
        </dl>
        <p className="mt-2 font-mono text-[10.5px] leading-4 text-ink-ghost">
          {systemStatus.llm.name}
          <br />
          {systemStatus.llm.runtime} · {systemStatus.llm.latency}
        </p>

        {/* Navigation */}
        <SectionLabel className="mb-2 mt-6">Navigate</SectionLabel>
        <ul className="space-y-0.5">
          {navItems.map((item) => {
            const active = item.id === view;
            const Icon = item.icon;
            return (
              <li key={item.id}>
                <button
                  type="button"
                  aria-current={active ? 'page' : undefined}
                  onClick={() => onChangeView(item.id)}
                  className={cn(
                    'group relative -mx-2 flex w-[calc(100%+1rem)] items-center gap-2.5 rounded-md px-2 py-[7px] text-left',
                    'transition-[background-color,color] duration-150 ease-swift',
                    active ?
                    'bg-white/[0.055] text-ink' :
                    'text-ink-dim hover:bg-white/[0.035] hover:text-ink'
                  )}>
                  
                  {active &&
                  <span className="absolute left-0 top-1/2 h-4 w-[2px] -translate-y-1/2 rounded-full bg-jade-400" />
                  }
                  <Icon
                    className={cn(
                      'h-4 w-4 shrink-0 transition-colors',
                      active ? 'text-jade-300' : 'text-ink-faint group-hover:text-ink-dim'
                    )}
                    strokeWidth={1.9} />
                  
                  <span className="flex-1 text-md font-medium tracking-[-0.01em]">
                    {item.label}
                  </span>
                  <span className="font-mono text-[10px] text-ink-ghost opacity-0 transition-opacity duration-150 group-hover:opacity-100">
                    {item.hint}
                  </span>
                </button>
              </li>);

          })}
        </ul>
      </div>
    </nav>);

}