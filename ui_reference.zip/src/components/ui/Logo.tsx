import React from 'react';

/** LocalMind brain mark — a lobed contour over a retrieval lattice. */
export function BrainMark({ className = 'h-4 w-4' }: {className?: string;}) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
      <path
        d="M12 4.2v15.6M12 4.2c-1.1-1.3-3.1-1.5-4.4-.4-.9.8-1.2 2-.8 3.1-1.4.3-2.4 1.5-2.4 3 0 .9.4 1.8 1 2.4-.7.6-1.1 1.5-1.1 2.5 0 1.9 1.6 3.4 3.5 3.4.6 0 1.2-.2 1.7-.5.5.8 1.4 1.3 2.5 1.3M12 4.2c1.1-1.3 3.1-1.5 4.4-.4.9.8 1.2 2 .8 3.1 1.4.3 2.4 1.5 2.4 3 0 .9-.4 1.8-1 2.4.7.6 1.1 1.5 1.1 2.5 0 1.9-1.6 3.4-3.5 3.4-.6 0-1.2-.2-1.7-.5-.5.8-1.4 1.3-2.5 1.3"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round" />
      
      <path
        d="M9 8.4h1.6M9 12h1.6M9.4 15.6H11M13 9.6h1.8M13.4 13.2H15"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        opacity="0.55" />
      
    </svg>);

}

export function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <span className="relative inline-flex h-7 w-7 items-center justify-center rounded-lg bg-jade-900 text-jade-300 shadow-[inset_0_0_0_1px_rgba(53,214,164,0.24)]">
        <BrainMark className="h-4 w-4" />
      </span>
      <span className="flex flex-col leading-none">
        <span className="font-display text-[14.5px] font-semibold tracking-[-0.02em] text-ink">
          LocalMind
        </span>
        <span className="mt-0.5 font-mono text-[9.5px] uppercase tracking-[0.14em] text-ink-ghost">
          on-device
        </span>
      </span>
    </div>);

}