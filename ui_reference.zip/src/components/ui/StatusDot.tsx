import React from 'react';
import { cn } from '../../utils/cn';

type State = 'ready' | 'working' | 'paused' | 'error';

const colors: Record<State, string> = {
  ready: 'bg-jade-400',
  working: 'bg-info-400',
  paused: 'bg-ink-ghost',
  error: 'bg-danger-500'
};

export function StatusDot({
  state,
  className,
  pulse




}: {state: State;className?: string;pulse?: boolean;}) {
  return (
    <span className={cn('relative flex h-1.5 w-1.5 shrink-0', className)}>
      <span className={cn('h-1.5 w-1.5 rounded-full', colors[state])} />
      {pulse &&
      <span
        className={cn(
          'absolute inset-0 rounded-full animate-pulse-soft',
          colors[state],
          'opacity-40'
        )} />

      }
    </span>);

}