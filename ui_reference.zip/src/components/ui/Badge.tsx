import React from 'react';
import { cn } from '../../utils/cn';

type Tone = 'neutral' | 'jade' | 'info' | 'warn' | 'danger';

const tones: Record<Tone, string> = {
  neutral: 'bg-white/[0.05] text-ink-dim',
  jade: 'bg-jade-900/70 text-jade-300',
  info: 'bg-info-900 text-info-400',
  warn: 'bg-warn-900 text-warn-400',
  danger: 'bg-danger-900 text-danger-400'
};

interface BadgeProps {
  tone?: Tone;
  children: React.ReactNode;
  className?: string;
  mono?: boolean;
}

export function Badge({ tone = 'neutral', children, className, mono }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex h-5 shrink-0 items-center gap-1 rounded-[5px] px-1.5 text-xs font-medium',
        mono && 'font-mono text-[10.5px]',
        tones[tone],
        className
      )}>
      
      {children}
    </span>);

}