import React from 'react';
import { cn } from '../../utils/cn';

export function SectionLabel({
  children,
  className,
  action




}: {children: React.ReactNode;className?: string;action?: React.ReactNode;}) {
  return (
    <div className={cn('flex items-center justify-between gap-2', className)}>
      <h3 className="text-2xs font-semibold uppercase text-ink-faint">{children}</h3>
      {action}
    </div>);

}

export function Panel({
  children,
  className,
  padded = true




}: {children: React.ReactNode;className?: string;padded?: boolean;}) {
  return (
    <section
      className={cn(
        'rounded-xl bg-surface-raised shadow-ring',
        padded && 'p-4',
        className
      )}>
      
      {children}
    </section>);

}

export function KeyValue({
  label,
  value,
  mono




}: {label: string;value: React.ReactNode;mono?: boolean;}) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-2xs font-semibold uppercase text-ink-ghost">{label}</span>
      <span className={cn('text-sm text-ink-dim', mono && 'font-mono text-[11.5px]')}>
        {value}
      </span>
    </div>);

}

export function Meter({
  value,
  tone = 'jade',
  className




}: {value: number;tone?: 'jade' | 'info' | 'warn';className?: string;}) {
  const fill =
  tone === 'jade' ? 'bg-jade-500' : tone === 'info' ? 'bg-info-500' : 'bg-warn-500';
  return (
    <div className={cn('h-[3px] w-full overflow-hidden rounded-full bg-white/[0.06]', className)}>
      <div
        className={cn('h-full rounded-full transition-[width] duration-300 ease-swift', fill)}
        style={{ width: `${Math.max(0, Math.min(1, value)) * 100}%` }} />
      
    </div>);

}

export function EmptyState({
  icon,
  title,
  description,
  action





}: {icon: React.ReactNode;title: string;description: string;action?: React.ReactNode;}) {
  return (
    <div className="flex flex-col items-start gap-2 rounded-xl bg-surface-raised/60 p-6 shadow-ring">
      <span className="mb-1 inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white/[0.04] text-ink-faint">
        {icon}
      </span>
      <p className="text-md font-medium text-ink">{title}</p>
      <p className="max-w-sm text-base text-ink-faint">{description}</p>
      {action ? <div className="mt-2">{action}</div> : null}
    </div>);

}