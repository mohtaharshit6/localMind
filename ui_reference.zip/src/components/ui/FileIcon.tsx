import React from 'react';
import {
  FileCode2Icon,
  FileSpreadsheetIcon,
  FileTextIcon,
  FileTypeIcon,
  NotebookTextIcon } from
'lucide-react';
import type { FileKind } from '../../types';
import { cn } from '../../utils/cn';

const config: Record<FileKind, {Icon: typeof FileTextIcon;fg: string;bg: string;}> = {
  pdf: { Icon: FileTypeIcon, fg: 'text-danger-400', bg: 'bg-danger-900/60' },
  docx: { Icon: NotebookTextIcon, fg: 'text-info-400', bg: 'bg-info-900' },
  csv: { Icon: FileSpreadsheetIcon, fg: 'text-jade-300', bg: 'bg-jade-900/70' },
  txt: { Icon: FileTextIcon, fg: 'text-ink-dim', bg: 'bg-white/[0.05]' },
  code: { Icon: FileCode2Icon, fg: 'text-warn-400', bg: 'bg-warn-900' }
};

export function FileIcon({
  kind,
  size = 'md',
  className




}: {kind: FileKind;size?: 'sm' | 'md';className?: string;}) {
  const { Icon, fg, bg } = config[kind];
  const box = size === 'sm' ? 'h-5 w-5 rounded-[5px]' : 'h-7 w-7 rounded-md';
  const glyph = size === 'sm' ? 'h-3 w-3' : 'h-3.5 w-3.5';
  return (
    <span
      className={cn('inline-flex shrink-0 items-center justify-center', box, bg, className)}
      aria-hidden="true">
      
      <Icon className={cn(glyph, fg)} strokeWidth={1.8} />
    </span>);

}