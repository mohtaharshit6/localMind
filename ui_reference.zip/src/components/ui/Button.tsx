import React from 'react';
import { cn } from '../../utils/cn';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
type Size = 'sm' | 'md';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  icon?: React.ReactNode;
  trailing?: React.ReactNode;
}

const variants: Record<Variant, string> = {
  primary:
  'bg-jade-500 text-void font-semibold hover:bg-jade-400 active:bg-jade-600 shadow-[0_1px_0_rgba(255,255,255,0.18)_inset,0_8px_20px_-10px_rgba(22,192,140,0.7)]',
  secondary:
  'bg-surface-high text-ink shadow-ring hover:bg-surface-hover active:bg-surface-high',
  ghost: 'text-ink-dim hover:text-ink hover:bg-white/[0.04] active:bg-white/[0.02]',
  danger:
  'bg-danger-900 text-danger-400 shadow-[inset_0_0_0_1px_rgba(244,101,91,0.32)] hover:bg-danger-700/60 hover:text-danger-400'
};

const sizes: Record<Size, string> = {
  sm: 'h-7 px-2.5 text-xs gap-1.5 rounded-md',
  md: 'h-9 px-3.5 text-sm gap-2 rounded-lg'
};

export function Button({
  variant = 'secondary',
  size = 'md',
  icon,
  trailing,
  className,
  children,
  ...rest
}: ButtonProps) {
  return (
    <button
      type="button"
      className={cn(
        'inline-flex items-center justify-center whitespace-nowrap font-medium',
        'transition-[background-color,color,box-shadow,transform] duration-150 ease-swift',
        'active:translate-y-px disabled:pointer-events-none disabled:opacity-40',
        sizes[size],
        variants[variant],
        className
      )}
      {...rest}>
      
      {icon}
      {children}
      {trailing}
    </button>);

}