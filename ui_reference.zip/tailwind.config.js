export default {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        void: '#08090A',
        surface: {
          DEFAULT: '#0E1011',
          raised: '#14171A',
          high: '#1B1F23',
          hover: '#22272C',
        },
        ink: {
          DEFAULT: '#E9ECEF',
          dim: '#9AA1A9',
          faint: '#6A7178',
          ghost: '#484E55',
        },
        jade: {
          100: '#D3F7EA',
          300: '#6EE7BE',
          400: '#35D6A4',
          500: '#16C08C',
          600: '#0FA275',
          700: '#0A6E51',
          900: '#093428',
        },
        danger: {
          400: '#FF8078',
          500: '#F4655B',
          700: '#7A2A26',
          900: '#3A1614',
        },
        warn: {
          400: '#EFBB63',
          500: '#E3A94B',
          900: '#3A2A11',
        },
        info: {
          400: '#7FB4F7',
          500: '#6BA8F5',
          900: '#152538',
        },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        display: ['"Inter Tight"', 'Inter', 'ui-sans-serif', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      fontSize: {
        '2xs': ['10px', { lineHeight: '14px', letterSpacing: '0.06em' }],
        xs: ['11px', { lineHeight: '16px', letterSpacing: '0.01em' }],
        sm: ['12.5px', { lineHeight: '18px' }],
        base: ['13.5px', { lineHeight: '21px' }],
        md: ['15px', { lineHeight: '24px' }],
        lg: ['17px', { lineHeight: '26px', letterSpacing: '-0.01em' }],
        xl: ['21px', { lineHeight: '28px', letterSpacing: '-0.015em' }],
        '2xl': ['26px', { lineHeight: '32px', letterSpacing: '-0.02em' }],
        '3xl': ['34px', { lineHeight: '40px', letterSpacing: '-0.025em' }],
        '4xl': ['44px', { lineHeight: '48px', letterSpacing: '-0.03em' }],
      },
      spacing: {
        4.5: '1.125rem',
        13: '3.25rem',
        18: '4.5rem',
      },
      boxShadow: {
        soft: '0 1px 2px rgba(0,0,0,0.4), 0 10px 28px -12px rgba(0,0,0,0.65)',
        lift: '0 2px 6px rgba(0,0,0,0.45), 0 24px 48px -20px rgba(0,0,0,0.8)',
        ring: 'inset 0 0 0 1px rgba(255,255,255,0.06)',
        jade: '0 0 0 1px rgba(22,192,140,0.28), 0 10px 30px -12px rgba(22,192,140,0.35)',
      },
      transitionTimingFunction: {
        swift: 'cubic-bezier(0.23, 1, 0.32, 1)',
      },
      keyframes: {
        'rise-in': {
          '0%': { opacity: '0', transform: 'translateY(6px) scale(0.985)' },
          '100%': { opacity: '1', transform: 'translateY(0) scale(1)' },
        },
        'pulse-soft': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.45' },
        },
      },
      animation: {
        'rise-in': 'rise-in 240ms cubic-bezier(0.23, 1, 0.32, 1) both',
        'pulse-soft': 'pulse-soft 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
    },
  },
  plugins: [],
}
